/** Package-owned invariant companion for `@deepseek-ai/dsh-client-rheplicant-ui-theme`. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "rheplicant-ui-theme-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map