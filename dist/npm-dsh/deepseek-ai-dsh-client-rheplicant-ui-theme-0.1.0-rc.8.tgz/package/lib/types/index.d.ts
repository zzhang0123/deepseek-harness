/** Node half of the rheplicant ui-theme client plugin. The browser half registers the theme. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map