/**
 * rheplicant "radio telescope observatory" palette, applied as a token
 * OVERRIDE layer over the active base theme (the brand-shading pattern).
 *
 * Scheme-aware (decided 2026-08-21, dark-first):
 * - dark: the deep-space navy console signature (base #07131f family).
 * - light: upstream rheplicant GUI workbench values (e-RHINO
 *   src/rheplicant/gui/react/tokens.css) — present so light "does not
 *   break", not a designed-first surface.
 * - the lit amber matches upstream `core/render.py _THEMES` exactly
 *   (#E3B341 dark / #BA7517 light): the host-rendered signal-path SVG
 *   uses those literals, and the chrome must not clash with it.
 *
 * `--dsw-rh-*` are rheplicant EXTENSION tokens (not dsh aliases): the
 * stale state, the graph node-kind palette, and chart scaffolding.
 * Chart series reuse the node palette — the chart palette IS the graph
 * palette, one identity (chain 0 amber, then source/transform/processing).
 */
import type { ThemeTokenOverrides } from '@deepseek-ai/dsh-client-ui-theme/client';
export declare const rheplicantOverrides: ThemeTokenOverrides;
//# sourceMappingURL=theme.d.ts.map