/**
 * Browser plugin for the rheplicant dark theme. Applies the rheplicant palette
 * as a token override layer over the active base theme — the brand-shading
 * pattern — so the console reads as a dark "radio telescope observatory"
 * regardless of the user's light/dark preference.
 * @module @rheplicant/dsh-rheplicant-ui-theme/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required services: the DSH theme registry. */
export declare const inject: string[];
/** Stack the rheplicant palette over the active theme for the plugin's lifetime. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map