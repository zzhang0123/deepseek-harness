/**
 * Browser plugin for the rheplicant compute settings card. Registers one
 * `settings.section` entry that reads/writes the `rheplicant-endpoints`
 * settings section through the seam's settings channel (no client→host RPC).
 * @module @rheplicant/dsh-rheplicant-ui-compute/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map