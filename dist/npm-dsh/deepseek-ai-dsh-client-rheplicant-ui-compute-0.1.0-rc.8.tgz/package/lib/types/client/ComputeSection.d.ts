import type { SettingsScope } from '@deepseek-ai/dsh-client-runtime/client';
/** Endpoint configuration (mirrors the SD's `ComputeEndpoints`). */
export interface ComputeEndpoints {
    readonly ssh?: {
        readonly host?: string;
        readonly command?: string;
    };
    readonly http?: {
        readonly baseUrl?: string;
    };
}
/** Render the compute settings card: transports + editable endpoints. */
export declare const ComputeSection: import("react").MemoExoticComponent<({ scope }: {
    scope: SettingsScope<ComputeEndpoints>;
}) => import("react").JSX.Element>;
//# sourceMappingURL=ComputeSection.d.ts.map