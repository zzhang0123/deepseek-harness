import type { DocumentFact } from './document-contract.ts';
export interface DocumentSourceProps {
    readonly fact: DocumentFact;
}
export declare const DocumentSource: import("react").MemoExoticComponent<({ fact }: DocumentSourceProps) => import("react").JSX.Element>;
//# sourceMappingURL=DocumentSource.d.ts.map