/**
 * Business Definitions folding the three durable rheplicant events into the
 * `rheplicant-document` conversation-view target. One Definition per event
 * type, each a one-shot fact (matches ui-loop's own
 * `loop-definitions.ts` shape for the identical three events: `id =
 * String(event.seq)`, always `role: 'start'`, `update` a no-op) — every
 * occurrence is its own Context, never merged with an earlier one. Reusing
 * a constant id per event type (the way `rheplicant-analysis` folds
 * `rheplicant/run` into a single 'chat' node) is NOT safe here: the
 * assembler throws if a Context already holding a start Match receives a
 * second one, so a session's second validate/gates/run call would crash a
 * Definition that tried to keep re-starting the same id. The one-shot-id
 * shape sidesteps that — the fold to "the single latest fact" happens in
 * the separate builder (`document-snapshot-builder.ts`).
 * @module @rheplicant/dsh-rheplicant-ui-document/client/document-definitions
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Register the three document-fact Definitions.
 * @param ctx - Plugin context receiving the Definitions.
 */
export declare function registerDocumentDefinitions(ctx: Context): void;
//# sourceMappingURL=document-definitions.d.ts.map