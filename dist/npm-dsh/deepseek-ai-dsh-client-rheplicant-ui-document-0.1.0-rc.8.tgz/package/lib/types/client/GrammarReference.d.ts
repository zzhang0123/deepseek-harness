export declare const GrammarReference: import("react").MemoExoticComponent<() => import("react").JSX.Element>;
//# sourceMappingURL=GrammarReference.d.ts.map