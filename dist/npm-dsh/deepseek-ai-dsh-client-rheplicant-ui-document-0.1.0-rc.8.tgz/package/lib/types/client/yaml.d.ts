/**
 * A small, deterministic YAML serializer for the plain JSON data a
 * `ComputeDocument` carries (§5: the panel renders the durable document
 * exactly as recorded — no re-authoring). Block style throughout, 2-space
 * indent, quotes only where a plain scalar would be ambiguous, no anchors
 * or aliases, no flow style beyond empty collections (`[]`/`{}`). Key order
 * is preserved exactly as parsed off the wire (JS object property order is
 * well-defined for string keys) rather than re-sorted — re-sorting would
 * misrepresent the document exactly as the agent authored it.
 *
 * `ComputeDocument = Record<string, unknown>`, but every value that reaches
 * the client already passed through the wire's own JSON boundary, so in
 * practice it is always null/boolean/number/string/array/plain-object.
 * `serializeDocument` still falls back to pretty JSON (labelled) if this
 * emitter ever throws on a shape it does not expect, so no document can
 * render as a false wall of nothing.
 * @module @rheplicant/dsh-rheplicant-ui-document/client/yaml
 */
import type { ComputeDocument } from '@rheplicant/dsh-rheplicant';
/** Render a config document as deterministic block-style YAML. */
export declare function toYaml(document: ComputeDocument): string;
export interface SerializedDocument {
    readonly text: string;
    readonly format: 'yaml' | 'json';
}
/** Serialize a document as YAML; fall back to pretty JSON (labelled) if the hand-rolled emitter ever throws on an unexpected shape. */
export declare function serializeDocument(document: ComputeDocument): SerializedDocument;
//# sourceMappingURL=yaml.d.ts.map