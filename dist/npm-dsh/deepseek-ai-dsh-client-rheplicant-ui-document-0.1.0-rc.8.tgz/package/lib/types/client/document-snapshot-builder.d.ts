/**
 * Per-session incremental builder for the `rheplicant-document`
 * conversation-view target. Simpler than ui-loop's own
 * `loop-snapshot-builder.ts` (the reference for this pattern): that builder
 * keeps the latest fact of each of three kinds side by side (the loop rail
 * needs all three at once); this one only ever needs the single most recent
 * fact across all three kinds, so it tracks one running maximum by
 * `anchorSeq` instead of a sorted contribution ledger.
 * @module @rheplicant/dsh-rheplicant-ui-document/client/document-snapshot-builder
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ConversationViewBuilder, ConversationViewDefinition } from '@deepseek-ai/dsh-client-runtime/client';
import type { DocumentConversationViewNode, DocumentSnapshot } from './document-contract.ts';
/** Stable empty target used until a Session has recorded any document fact. */
export declare const EMPTY_DOCUMENT_SNAPSHOT: DocumentSnapshot;
/** Per-Session incremental builder keeping only the single most recent document fact. */
export declare class DocumentSnapshotBuilder implements ConversationViewBuilder<DocumentConversationViewNode, DocumentSnapshot> {
    private readonly nodes;
    private latest;
    readonly empty: DocumentSnapshot;
    replace(input: {
        readonly nodes: readonly DocumentConversationViewNode[];
    }): DocumentSnapshot;
    apply(input: {
        readonly upserts: readonly DocumentConversationViewNode[];
    }): DocumentSnapshot;
    private upsert;
    private snapshot;
}
/** The document target factory: one fresh builder per Session. */
export declare const documentViewDefinition: ConversationViewDefinition<DocumentConversationViewNode, DocumentSnapshot>;
/**
 * Register the `rheplicant-document` conversation-view target builder.
 * @param ctx - Plugin context receiving the view Definition.
 */
export declare function registerDocumentConversationView(ctx: Context): void;
//# sourceMappingURL=document-snapshot-builder.d.ts.map