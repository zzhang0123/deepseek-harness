import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
interface DocumentPanelProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
}
export declare const DocumentPanel: import("react").MemoExoticComponent<({ useSession }: DocumentPanelProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=DocumentPanel.d.ts.map