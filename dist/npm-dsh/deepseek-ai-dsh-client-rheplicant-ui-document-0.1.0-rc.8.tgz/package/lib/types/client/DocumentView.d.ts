import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
interface DocumentViewProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
}
export declare const DocumentView: import("react").MemoExoticComponent<({ useSession }: DocumentViewProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=DocumentView.d.ts.map