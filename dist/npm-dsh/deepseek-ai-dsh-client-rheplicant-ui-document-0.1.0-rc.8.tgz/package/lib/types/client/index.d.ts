/**
 * Browser plugin for the config-document view: the `conversation.view`
 * Document tab (exact document + generated grammar reference). Also
 * registers this package's own `rheplicant-document`
 * conversation-view projection: a private fold of the three durable
 * rheplicant events down to whichever most recently carried a document (§5
 * of docs/architecture.md: a panel reads the durable session log, it never
 * calls compute) — independent of any other package's own projection of the
 * same events, so this package's read path stays self-contained.
 * @module @rheplicant/dsh-rheplicant-ui-document/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map