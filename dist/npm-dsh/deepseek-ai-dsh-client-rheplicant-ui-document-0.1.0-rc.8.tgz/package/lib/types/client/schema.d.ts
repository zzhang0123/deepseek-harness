/** Static projection of the config-document grammar (generated from rheplicant.config.schema.json_schema). */
export interface ConfigSection {
    readonly name: string;
    readonly required: boolean;
    readonly status: string;
}
export interface ConfigSchema {
    readonly schemaVersion: string;
    readonly sections: readonly ConfigSection[];
    readonly exits: readonly string[];
    readonly operators: readonly string[];
    readonly transforms: readonly string[];
    readonly catalogs: {
        readonly acceptedUnits: readonly string[];
        readonly resourceKinds: readonly string[];
        readonly fileFormats: readonly string[];
        readonly shapeSymbols: readonly string[];
    };
}
export declare const SCHEMA: ConfigSchema;
//# sourceMappingURL=schema.d.ts.map