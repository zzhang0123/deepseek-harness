/** Package-owned invariant companion for `@rheplicant/dsh-rheplicant-ui-document`. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "rheplicant-ui-document-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map