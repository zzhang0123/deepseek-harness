/** Node half of the rheplicant ui-document client plugin (empty apply). */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map