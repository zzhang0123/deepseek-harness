/**
 * What changed between the document that RAN and the document as authored.
 *
 * `docs/project-model.md` §11.4 left this open: P7c made *as authored* vs *as
 * it ran* visible through the DIGEST, which answers whether they differ, and
 * recorded that showing the execution's `config.input.yaml` beside it "is
 * still worth doing and is NOT done". A flag that says a task changed and
 * cannot say how leaves the reader to diff two YAML files by eye, which is
 * the drudgery a tool exists to remove.
 *
 * **A line diff, not a side-by-side pair of panes.** The question is *what
 * changed*, and a marked-up single column answers it at any width, where two
 * panes need room this panel does not always have and still leave the reader
 * finding the differences themselves.
 *
 * **A replacement reads as a removal then an addition**, never as one
 * "changed" line. A YAML edit that rewrites a value is legible only if both
 * the old and the new text are on screen.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/document-diff
 */
/** How one line relates to the two documents. */
export type DiffLineKind = 'same' | 'removed' | 'added';
/** One line of the comparison. */
export interface DiffLine {
    readonly kind: DiffLineKind;
    readonly text: string;
    /**
     * 1-based line number in the EXECUTED document, absent for an added line.
     *
     * Numbered independently of {@link authoredAt}, because one shared counter
     * would make the gutter lie about where to look in the file you are about
     * to edit.
     */
    readonly ranAt?: number;
    /** 1-based line number in the AUTHORED document, absent for a removed line. */
    readonly authoredAt?: number;
}
/**
 * The largest document either side may have before the comparison is refused.
 *
 * The algorithm is O(n·m), so this is the bound that keeps one generated
 * config from freezing the workbench. Announced rather than silent: a diff
 * that quietly gave up would render as "nothing changed", which is the one
 * answer it must never give by accident.
 */
export declare const MAX_DIFF_LINES = 2000;
/**
 * Compare the executed document against the authored one.
 *
 * @param ran - `config.input.yaml`, the exact bytes this execution used.
 * @param authored - the task file as it stands now.
 * @returns the lines in reading order, or `'too-large'` when either side
 *   exceeds {@link MAX_DIFF_LINES}.
 */
export declare function diffLines(ran: string, authored: string): readonly DiffLine[] | 'too-large';
/** Whether a comparison found any difference at all. */
export declare function hasChanges(diff: readonly DiffLine[] | 'too-large'): boolean;
//# sourceMappingURL=document-diff.d.ts.map