/**
 * Browser plugin for the rheplicant project home (`docs/project-model.md`
 * §6.0): the archive surface, root-scoped, over a project's tasks, inputs and
 * executions.
 *
 * Two registrations into two ADDITIVE root-scoped list slots, both
 * `replaceRisk: 'none'`:
 *
 * * `shell.overlay` — the page itself. Its own contract calls it "the additive
 *   seat for a frame-wide surface of your own", which is exactly what an
 *   archive page is.
 * * `sidebar.footer.action` — the control that opens it, beside Settings.
 *
 * Neither shadows shipped UI. §6.0 originally named
 * `conversation.hero.workspace`; `ProjectHome.tsx`'s header records why that
 * turned out to be the wrong seat (it is a single-occupant popover already
 * owned by the WorkspacePicker, and taking it would break the directory-flow
 * child slot too).
 *
 * The two halves share open-state through a module-level store rather than a
 * slot channel — see `home-store.ts` for why that is both necessary here and
 * safe here.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { closeHome, openHome, readHome, resetHome, selectProject, toggleHome, useHome } from './home-store.ts';
export type { HomeState } from './home-store.ts';
export { countByStatus, formatBytes, groupExecutionsByTask, taskSegmentOf, } from './home-selectors.ts';
export type { StatusCounts, TaskExecutionGroup } from './home-selectors.ts';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map