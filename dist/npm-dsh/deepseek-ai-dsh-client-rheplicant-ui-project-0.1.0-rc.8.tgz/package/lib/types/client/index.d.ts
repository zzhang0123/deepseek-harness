/**
 * Browser plugin for the rheplicant workbench (`docs/project-model.md`
 * §6.0): the archive surface, root-scoped, over a project's tasks, inputs and
 * executions.
 *
 * Two registrations into two ADDITIVE root-scoped list slots, both
 * `replaceRisk: 'none'`:
 *
 * * `shell.overlay` — the page itself. Its own contract calls it "the additive
 *   seat for a frame-wide surface of your own", which is exactly what an
 *   archive page is.
 * * `sidebar.footer.action` — the control that opens it, beside Settings.
 *
 * Neither shadows shipped UI. §6.0 originally named
 * `conversation.hero.workspace`; `ProjectHome.tsx`'s header records why that
 * turned out to be the wrong seat (it is a single-occupant popover already
 * owned by the WorkspacePicker, and taking it would break the directory-flow
 * child slot too).
 *
 * The two halves share open-state through a module-level store rather than a
 * slot channel — see `home-store.ts` for why that is both necessary here and
 * safe here.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client
 */
import type { ClientContext, ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { LoopExecutionView, PanelLayoutView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
/**
 * What the workbench hands each panel.
 *
 * `useSession` is an OWNER prop here, not a standard one: `task.panel` is
 * root-scoped, so the slot runtime supplies no session reader — and that is
 * the point (§11.3). The workbench supplies one that reads an empty
 * conversation, which is the truthful answer for a surface that has none, and
 * lets a panel written for the console render here unchanged.
 */
export interface TaskPanelOwnerProps {
    /** An empty conversation: the workbench contributes no session log. */
    readonly useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    /** The selected execution, in the same shape the console builds. */
    readonly execution: LoopExecutionView;
    /**
     * Which panels are collapsed or hidden (§20.4).
     *
     * The one channel that reaches every occupant: `renderSlot`'s second
     * argument is identical for every row of a list slot, so an occupant reads
     * its OWN state out of this by its OWN known id and self-applies it. A panel
     * that ignores it is simply unmanaged — no error, always visible.
     */
    readonly layout: PanelLayoutView;
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /**
         * The workbench's panel grid: the same occupants `console.panel` carries,
         * rendered against the PROJECT selection instead of a session.
         *
         * Root scope on purpose — a panel here is driven by owner props, so it
         * needs nothing from a conversation, and requiring one is exactly the
         * coupling §11 removes.
         */
        'task.panel': {
            kind: 'list';
            scope: 'root';
            owner: TaskPanelOwnerProps;
        };
    }
}
export { closeHome, openHome, readHome, resetHome, selectProject, showSection, subscribeHome, toggleHome, toggleSection, useHome, type Section, } from './home-store.ts';
export type { HomeState } from './home-store.ts';
export { countByStatus, formatBytes, groupExecutionsByTask, taskSegmentOf, } from './home-selectors.ts';
export { canNavigate, openProject, setNavigator } from './navigate.ts';
export { KNOWN_PANELS } from './known-panels.ts';
export type { KnownPanel } from './known-panels.ts';
export { panelsWithNoExit } from './panel-relevance.ts';
export { createWorkbenchLayoutStore } from './layout-store.ts';
export { followSession, leavesSection } from './session-follow.ts';
export type { CurrentSession, CurrentSessionSource } from './session-follow.ts';
export { clearSelection, proposeSelection, readSelection, resetSelections, selectInProject, subscribeSelection, useSelection, } from './selection.ts';
export type { ProjectSelection, SelectionPatch, SelectionPins } from './selection.ts';
export { SelectionRuntime } from './selection-service.ts';
export { WorkbenchRuntime } from './workbench-service.ts';
export type { Navigator } from './navigate.ts';
export type { StatusCounts, TaskExecutionGroup } from './home-selectors.ts';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map