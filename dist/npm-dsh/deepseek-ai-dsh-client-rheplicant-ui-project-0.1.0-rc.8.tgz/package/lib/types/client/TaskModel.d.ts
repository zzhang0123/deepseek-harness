/**
 * What physics this task DECLARES, and the diagram of where it sits.
 *
 * `docs/project-model.md` §17, closing the philosophy doc's gap 2 ("the 29
 * operators do not appear in the UI") in its read-only half. Two of the five
 * anti-blackbox mechanisms, neither of which was reachable before a first
 * run: the canonical graph, which the doc asks to be "always present on
 * screen", and the operator catalogue.
 *
 * **Only the LIT nodes are listed.** The canonical graph has 33 and an
 * ordinary document lights three; the dimmed remainder is what the DIAGRAM
 * shows, and listing thirty operators nobody declared would bury the three
 * that are the model. The total is stated, because "3 of 33" is how a reader
 * learns there is more physics available than they have used.
 *
 * **`help` is the operator's own docstring**, lifted upstream. Nothing here
 * describes what a parameter means — a second description is a second thing
 * to drift from the physics.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/TaskModel
 */
import type { DocumentModel } from '@rheplicant/dsh-rheplicant';
interface TaskModelProps {
    readonly svg: string;
    readonly model: DocumentModel;
}
export declare const TaskModel: import("react").MemoExoticComponent<({ svg, model }: TaskModelProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=TaskModel.d.ts.map