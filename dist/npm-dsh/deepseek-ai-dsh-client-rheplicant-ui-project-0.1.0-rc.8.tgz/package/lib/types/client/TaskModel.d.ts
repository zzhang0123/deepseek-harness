/**
 * What physics this task DECLARES, and the diagram of where it sits.
 *
 * `docs/project-model.md` §17, closing the philosophy doc's gap 2 ("the 29
 * operators do not appear in the UI") in its read-only half. Two of the five
 * anti-blackbox mechanisms, neither of which was reachable before a first
 * run: the canonical graph, which the doc asks to be "always present on
 * screen", and the operator catalogue.
 *
 * **Only the LIT nodes are listed.** The canonical graph has 33 and an
 * ordinary document lights three; the dimmed remainder is what the DIAGRAM
 * shows, and listing thirty operators nobody declared would bury the three
 * that are the model. The total is stated, because "3 of 33" is how a reader
 * learns there is more physics available than they have used.
 *
 * **`help` is the operator's own docstring**, lifted upstream. Nothing here
 * describes what a parameter means — a second description is a second thing
 * to drift from the physics.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/TaskModel
 */
import type { DocumentModel } from '@rheplicant/dsh-rheplicant';
/**
 * Which projection is on screen, and how to change it.
 *
 * `docs/project-model.md` §28.1. The workbench used to draw this diagram AND
 * carry a `signal-path` panel drawing the selected execution's — two copies of
 * one picture, in two different themes, with neither saying which it was. The
 * panel is gone; the comparison it was accidentally providing is here, stated.
 *
 * **The words are "as authored" and "as it ran", and they are not new.** The
 * document panel on this same surface is subtitled "as authored" and its
 * caption reads "Identical to what <id> ran"; §11.4 calls the pair
 * "as authored vs as it ran". A first draft here said "as declared / as run"
 * and a review caught it: one idea with two names on one page reads as two
 * unrelated features, and "declared" already means something else INSIDE this
 * panel — the lit/dim encoding is what a document declares, so a switch
 * labelled "as declared" over a lit/dim graph reads as a filter.
 */
export interface ModelSourceView {
    /** Which projection is being rendered. */
    readonly showing: 'authored' | 'as-run';
    /** Switch. Absent when there is no execution of THIS task to compare with. */
    readonly onShow?: (showing: 'authored' | 'as-run') => void;
    /** The execution the as-run side reads, when there is one. */
    readonly executionId?: string;
    /**
     * How the as-run projection is getting on. Meaningful only while `showing`
     * is `as-run`, and load-bearing: the panel refuses to draw the AUTHORED
     * diagram under an as-run label, so this is what it draws instead.
     */
    readonly state?: 'ready' | 'loading' | 'unavailable';
    /**
     * True when the authored bytes are the executed bytes, false when they are
     * not, and ABSENT when the comparison could not be made — the same three
     * values the maturity rail's stale flag carries, and for the same reason.
     */
    readonly identical?: boolean;
}
interface TaskModelProps {
    readonly svg: string;
    readonly model: DocumentModel;
    /** Absent outside the workbench, where there is nothing to compare. */
    readonly source?: ModelSourceView;
}
export declare const TaskModel: import("react").MemoExoticComponent<({ svg, model, source }: TaskModelProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=TaskModel.d.ts.map