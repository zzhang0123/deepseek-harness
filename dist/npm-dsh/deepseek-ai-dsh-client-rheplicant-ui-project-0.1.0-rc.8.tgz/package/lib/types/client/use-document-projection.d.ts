/**
 * The selected task's signal path and declared physics, needing no execution.
 *
 * `docs/project-model.md` §17. The same three-state discipline every reader
 * here uses, with one addition worth naming: `rheplicant.gui` is an OPTIONAL
 * extra, so "could not be reached" is a normal state on a working install and
 * not a fault to report as one.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/use-document-projection
 */
import type { ProjectDocumentProjectionBody } from '@rheplicant/dsh-rheplicant';
/** What the workbench knows about the projection it is showing. */
export interface DocumentProjectionState {
    readonly projection: ProjectDocumentProjectionBody | undefined;
    readonly loading: boolean;
    /** True when the host REFUSED the path — different from unreachable. */
    readonly refused: boolean;
    /** Which task this describes; never render it under another. */
    readonly shownFor: string | undefined;
}
/**
 * The key a projection is held under, and the one definition of it.
 *
 * Exported because the CALLER needs it too: "this state describes the request
 * I just made" is a different fact from `loading`, and only the key can tell
 * them apart. Between a caller changing its arguments and the effect below
 * firing there is a render where `loading` is false and `shownFor` still names
 * the previous request — and reading that as "settled" is how a panel comes to
 * report a failure for a fetch that was never attempted.
 *
 * @param workspaceId - the project.
 * @param taskPath - the task.
 * @param executionId - the execution, for an as-run projection.
 * @returns the key, or undefined when there is nothing to project.
 */
export declare function projectionKey(workspaceId: string | undefined, taskPath: string | undefined, executionId?: string): string | undefined;
/**
 * Project a document: the selected task, or the bytes an execution ran.
 *
 * **One hook, two sources (§28.1).** With `executionId` it projects that
 * execution's `config.input.yaml` through the same route and therefore the
 * same renderer, which is what lets the Model section put "as declared"
 * beside "as run" without the two differing in colour before they differ in
 * content.
 *
 * @param workspaceId - the project, or undefined when none is chosen.
 * @param taskPath - the task, or undefined when none is chosen.
 * @param nonce - bump to re-project the same task.
 * @param executionId - project what THIS execution ran instead of the task as
 *   it stands. Absent for the declared projection.
 * @returns the projection and the states around it.
 */
export declare function useDocumentProjection(workspaceId: string | undefined, taskPath: string | undefined, nonce?: number, executionId?: string): DocumentProjectionState;
//# sourceMappingURL=use-document-projection.d.ts.map