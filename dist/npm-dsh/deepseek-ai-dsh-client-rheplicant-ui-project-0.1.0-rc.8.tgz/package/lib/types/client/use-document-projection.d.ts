/**
 * The selected task's signal path and declared physics, needing no execution.
 *
 * `docs/project-model.md` §17. The same three-state discipline every reader
 * here uses, with one addition worth naming: `rheplicant.gui` is an OPTIONAL
 * extra, so "could not be reached" is a normal state on a working install and
 * not a fault to report as one.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/use-document-projection
 */
import type { ProjectDocumentProjectionBody } from '@rheplicant/dsh-rheplicant';
/** What the workbench knows about the projection it is showing. */
export interface DocumentProjectionState {
    readonly projection: ProjectDocumentProjectionBody | undefined;
    readonly loading: boolean;
    /** True when the host REFUSED the path — different from unreachable. */
    readonly refused: boolean;
    /** Which task this describes; never render it under another. */
    readonly shownFor: string | undefined;
}
/**
 * Project the selected task.
 *
 * @param workspaceId - the project, or undefined when none is chosen.
 * @param taskPath - the task, or undefined when none is chosen.
 * @param nonce - bump to re-project the same task.
 * @returns the projection and the states around it.
 */
export declare function useDocumentProjection(workspaceId: string | undefined, taskPath: string | undefined, nonce?: number): DocumentProjectionState;
//# sourceMappingURL=use-document-projection.d.ts.map