/**
 * Every registered project's overview, read one workspace at a time.
 *
 * N reads over the seam, not one aggregate route, and that is the design rather
 * than a first cut. `docs/project-model.md` §5 makes the project FOLDER the
 * source of truth and §5.1 makes any index a rebuildable cache; a server-side
 * aggregate would be that index, and it would have to be invalidated by
 * something — which is the failure the tree-as-truth rule exists to avoid. The
 * existing per-project route already answers exactly this question, so the
 * cross-project view is a fan-out over an answer that is already correct.
 *
 * FOUR STATES, kept apart for the same reason the single-project hook keeps
 * three (`use-project-overview.ts`): they read differently on screen and
 * confusing them is the failure this design exists to avoid.
 *
 * * loading, nothing yet — asked, no answers. Render nothing, not "empty".
 * * a project that ANSWERED — its overview, however empty.
 * * a project that could not be READ — no route plugin, an id the registry
 *   dropped, a folder that vanished. Say so about THAT project; the others are
 *   unaffected, which is the whole reason each is fetched separately.
 * * no projects at all — the registry is empty. An invitation, not a failure.
 *
 * A partial answer is shown as it arrives rather than held for the slowest
 * project. One unreadable project must not blank a dashboard of five.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/use-all-projects
 */
import { type ProjectOverviewBody, type ProjectTriggersBody } from './project-overview-client.ts';
/** One project's row in the cross-project view. */
export interface ProjectCard {
    readonly workspaceId: string;
    /** The registry's title, which is what the sidebar shows for this project. */
    readonly title: string;
    /**
     * The project's contents, or undefined when it could not be read.
     *
     * Undefined is NOT "empty project": an empty project answers with empty
     * lists. This means the answer never arrived, and a card that rendered "0
     * tasks" for it would state something it does not know.
     */
    readonly overview: ProjectOverviewBody | undefined;
    /**
     * What this project has asked to run on its own, or undefined when the route
     * could not be asked.
     *
     * A SEPARATE field from {@link overview} rather than a member of it, because
     * the two answer different questions and fail independently: the trigger
     * registry is one flat file this layer writes, the overview is a walk of the
     * results tree. A corrupt registry (`state: 'unreadable'`) must not blank the
     * task list, and an unreadable project must not be reported as having no
     * schedules.
     */
    readonly triggers: ProjectTriggersBody | undefined;
}
/** What the dashboard knows about every project. */
export interface AllProjectsState {
    /** True until every project has answered or failed. */
    readonly loading: boolean;
    readonly cards: readonly ProjectCard[];
}
/** One workspace as the registry describes it, narrowed to what this needs. */
export interface WorkspaceRef {
    readonly workspaceId: string;
    readonly title: string;
}
/**
 * Read every project's overview.
 *
 * @param workspaces - the registry's projects, in the order it lists them.
 * @param nonce - bump to re-read every project (the Refresh control).
 * @returns the cards, filling in as answers arrive.
 */
export declare function useAllProjects(workspaces: readonly WorkspaceRef[], nonce?: number): AllProjectsState;
//# sourceMappingURL=use-all-projects.d.ts.map