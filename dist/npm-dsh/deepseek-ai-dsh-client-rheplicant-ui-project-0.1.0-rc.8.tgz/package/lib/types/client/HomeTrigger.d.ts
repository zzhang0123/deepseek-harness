/**
 * The sidebar-foot control that opens the project home.
 *
 * `sidebar.footer.action` is a root-scoped LIST slot with `replaceRisk: none`,
 * so this is added beside the shipped Settings row rather than shadowing
 * anything — the reason this seat was chosen over §6.0's original
 * `conversation.hero.workspace`, which is a single-occupant popover already
 * owned by the shipped WorkspacePicker (see `docs/project-model.md` §6.0's
 * implementation note).
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/HomeTrigger
 */
/** What the sidebar hands every footer action: whether the column is wide. */
interface HomeTriggerProps {
    /** False when the sidebar is the 56px rail, so the label has no room. */
    readonly wide: boolean;
}
export declare const HomeTrigger: import("react").MemoExoticComponent<({ wide }: HomeTriggerProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=HomeTrigger.d.ts.map