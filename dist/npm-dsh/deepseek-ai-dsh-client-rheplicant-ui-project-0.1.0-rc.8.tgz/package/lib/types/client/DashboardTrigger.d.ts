/**
 * The primary-navigation row that switches to the dashboard.
 *
 * Deliberately a near-twin of `HomeTrigger` rather than a shared component
 * parameterised by section. Two rows is where a shared abstraction is at its
 * least informative — it would take a section name, an icon and a label, which
 * is the whole component — and the rule-of-three the transport package records
 * applies here too: the third nav row is when the shape is known, not the
 * second. What IS shared is the store: both rows call `toggleSection`, and one
 * variable holding one section name is what makes them mutually exclusive.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/DashboardTrigger
 */
/** What the sidebar hands every nav row: whether the column is wide. */
interface DashboardTriggerProps {
    /** False when the sidebar is the 56px rail, so the label has no room. */
    readonly wide: boolean;
}
export declare const DashboardTrigger: import("react").MemoExoticComponent<({ wide }: DashboardTriggerProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=DashboardTrigger.d.ts.map