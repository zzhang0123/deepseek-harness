/**
 * What changed between the document that RAN and the document as authored.
 *
 * The half of `docs/project-model.md` §11.4 that P7c left open. The digest
 * comparison already answers *whether* a task changed; this answers *what*,
 * which is the only form of that answer somebody can act on.
 *
 * Long runs of unchanged lines collapse to a marker. A config document is
 * mostly unchanged even after a real edit, and a wall of context is how a
 * three-line change becomes invisible.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/DocumentDiff
 */
interface DocumentDiffProps {
    /** `config.input.yaml` — the exact bytes this execution ran. */
    readonly ran: string;
    /** The task file as it stands now. */
    readonly authored: string;
    /** The execution the left-hand side belongs to, named on screen. */
    readonly executionId: string;
}
export declare const DocumentDiff: import("react").MemoExoticComponent<({ ran, authored, executionId }: DocumentDiffProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=DocumentDiff.d.ts.map