/**
 * The task-maturity rail: how far THIS TASK has got toward being trustworthy.
 *
 * The workbench half of the split in `docs/project-model.md` §11.4. It answers
 * "should I believe this task's results", from evidence on disk, and therefore
 * survives every conversation. The console keeps the other half — what this
 * session just did — which answers a different question from a different
 * source.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/TaskMaturity
 */
import { type MaturityInput } from './task-maturity.ts';
/** Everything the rail needs, passed straight through to the selectors. */
export type TaskMaturityProps = MaturityInput;
export declare const TaskMaturity: import("react").MemoExoticComponent<(props: TaskMaturityProps) => import("react").JSX.Element>;
//# sourceMappingURL=TaskMaturity.d.ts.map