/**
 * The selected task's document, fetched when the selection names one.
 *
 * The same three-state discipline the overview uses, for the same reason: a
 * document that could not be READ and a task that has no document are
 * different facts, and rendering one as the other sends someone looking for a
 * bug in their own project.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/use-task-document
 */
import { type TaskDocumentBody } from './project-overview-client.ts';
/** What the workbench knows about the document it is showing. */
export interface TaskDocumentState {
    readonly loading: boolean;
    /** The document, or undefined when it could not be read. */
    readonly document: TaskDocumentBody | undefined;
    /** True when the host REFUSED the path — a different fact from unreachable. */
    readonly refused: boolean;
    /** Which task {@link document} belongs to; never render it under another. */
    readonly shownFor: string | undefined;
}
/**
 * Fetch the selected task's document.
 *
 * @param workspaceId - the project, or undefined when none is chosen.
 * @param taskPath - the task, or undefined when none is chosen.
 * @param nonce - bump to re-read the same document.
 * @returns the document and the states around it.
 */
export declare function useTaskDocument(workspaceId: string | undefined, taskPath: string | undefined, nonce?: number): TaskDocumentState;
//# sourceMappingURL=use-task-document.d.ts.map