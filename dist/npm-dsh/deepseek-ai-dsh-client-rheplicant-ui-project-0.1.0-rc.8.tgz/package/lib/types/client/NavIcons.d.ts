/**
 * The two primary-navigation icons, in dsh's own icon idiom.
 *
 * **They replace `◇` and `◈`, which were text glyphs.** A glyph comes from
 * whichever font resolves it, so its weight, its optical size and its baseline
 * were the browser's choice rather than ours — beside `IconNewChatOutline16`
 * one row up, which is a 16-unit filled path at a size the sidebar chooses.
 * The stack read as one designed control and two afterthoughts, which is what
 * a user report called it. This is the same fix `Brand.tsx` records for the
 * `◆` the mark used to be, in a second place.
 *
 * Filled paths on a `0 0 16 16` viewBox, `currentColor`, sized by the caller —
 * every one of those is copied from `ui-primitives`' icons rather than chosen
 * here, so the two rows and the button above them share a drawing convention
 * rather than merely a colour.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/NavIcons
 */
/** What the sidebar's own icons take. */
interface NavIconProps {
    readonly size: number;
}
/**
 * Dashboard: four tiles.
 *
 * The surface IS a grid of projects, so the icon is the layout rather than a
 * metaphor for it — and four equal tiles say "all of them", which is the one
 * thing that distinguishes this destination from the workbench beside it.
 */
export declare const IconDashboard: import("react").MemoExoticComponent<({ size }: NavIconProps) => import("react").JSX.Element>;
/**
 * Workbench: one panelled surface.
 *
 * A frame with its header bar — ONE project's surface, where the dashboard is
 * every project's. Deliberately not a second grid: at the 14px the sidebar
 * renders these, two grids differing only in cell count are the same icon.
 */
export declare const IconWorkbench: import("react").MemoExoticComponent<({ size }: NavIconProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=NavIcons.d.ts.map