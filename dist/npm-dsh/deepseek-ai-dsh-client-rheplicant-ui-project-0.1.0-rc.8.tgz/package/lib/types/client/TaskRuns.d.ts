/**
 * The exits: what this task computes, and what it is not reaching for.
 *
 * `docs/project-model.md` §18 — the philosophy doc's gap 5. It replaces the
 * six empty viz panels that each said "Ask the agent for a nuts run": one
 * sentence per panel, mentioning four of the eighteen exits, and only visible
 * when you happened to be looking at a task that could not fill that panel.
 *
 * **No capability column.** rheplicant has no capability concept in code —
 * see `task-runs.ts`. What is shown instead is what the source defends:
 * whether an exit needs a fitted parameter space, and what it produces.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/TaskRuns
 */
import type { DocumentRuns } from '@rheplicant/dsh-rheplicant';
export declare const TaskRuns: import("react").MemoExoticComponent<({ runs }: {
    runs: DocumentRuns;
}) => import("react").JSX.Element>;
//# sourceMappingURL=TaskRuns.d.ts.map