/**
 * sha256 of the authored task document, so staleness can be a DIGEST
 * comparison.
 *
 * `docs/project-model.md` §4.2 is explicit that staleness is content-based —
 * "Content digest, not revision number" — and it is inherited from
 * rheplicant's own `gui/jobs.py`. Comparing modification times instead would
 * be a weaker claim wearing the same word, and would call a task stale for a
 * touch that changed nothing.
 *
 * Answers `undefined` rather than throwing when it cannot hash. `crypto.subtle`
 * exists only in a secure context, which `localhost` is and a plain-http
 * deployment on another host is not — and "we could not compare" is a state
 * the rail already renders differently from "they differ".
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/use-document-digest
 */
/**
 * Digest one document's text.
 *
 * @param text - the document, or undefined when none is loaded.
 * @returns the hex digest, or undefined while hashing or when it is impossible.
 */
export declare function useDocumentDigest(text: string | undefined): string | undefined;
//# sourceMappingURL=use-document-digest.d.ts.map