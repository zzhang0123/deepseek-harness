/** One workspace row, as the registry hands it over. */
interface WorkspaceRow {
    readonly workspaceId: string;
    readonly title: string;
}
interface DashboardProps {
    useWorkspaces: <T>(selector: (state: {
        items: readonly WorkspaceRow[];
    }) => T) => T;
}
export declare const Dashboard: import("react").MemoExoticComponent<({ useWorkspaces }: DashboardProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=Dashboard.d.ts.map