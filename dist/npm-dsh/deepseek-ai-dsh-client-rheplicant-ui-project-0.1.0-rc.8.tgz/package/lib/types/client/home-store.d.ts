/**
 * Whether the project home is open, shared between the trigger and the page.
 *
 * A module-level store rather than a framework one, and the reason is
 * structural: the two halves of this feature occupy two DIFFERENT slots —
 * `sidebar.footer.action` for the trigger and `shell.overlay` for the page —
 * so no React context spans them and no owner-props channel connects them
 * (that channel runs from one owner to ITS occupants, and these two have
 * different owners).
 *
 * This is safe here for exactly the reason the same trick is NOT safe in
 * `ui-kit`: ui-kit is INLINED into each consuming plugin's bundle, so a
 * module-level value there is one copy per plugin and shares nothing. Both
 * readers here live in THIS plugin's single bundle, so they see one module
 * instance and one value.
 *
 * Deliberately not persisted. The home is a chooser, and an app that reopened
 * a full-frame overlay on every reload would be an app you have to dismiss
 * before you can work.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/home-store
 */
/** What the home is showing: closed, or open on one project. */
export interface HomeState {
    readonly open: boolean;
    /** The workspace whose project is being inspected, when one is chosen. */
    readonly workspaceId: string | undefined;
}
/** Open the home, optionally on a specific project. */
export declare function openHome(workspaceId?: string): void;
/** Close the home, remembering which project was being inspected. */
export declare function closeHome(): void;
/** Toggle the home — what the sidebar trigger does. */
export declare function toggleHome(): void;
/** Choose which project the home inspects. */
export declare function selectProject(workspaceId: string): void;
/** Reset to closed with no selection. Exists for tests, which share a module. */
export declare function resetHome(): void;
/** Read the current state without subscribing. */
export declare function readHome(): HomeState;
/** Subscribe a component to the home state. */
export declare function useHome(): HomeState;
//# sourceMappingURL=home-store.d.ts.map