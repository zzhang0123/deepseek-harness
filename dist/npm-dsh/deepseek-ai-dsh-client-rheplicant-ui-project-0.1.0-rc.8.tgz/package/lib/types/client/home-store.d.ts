/**
 * Which of the two peer sections is on screen — the project, or the
 * conversation — shared between the switch and the page.
 *
 * `docs/project-model.md` §20.2. This was an OPEN/CLOSED flag for a modal
 * overlay; it is a SECTION flag now, and the difference is not cosmetic. A
 * modal is a thing you dismiss before you can work; a section is a place you
 * are, and a place you are is a thing the app should still know about after a
 * reload. So this persists, where the modal deliberately did not — its own
 * comment used to say "an app that reopened a full-frame overlay on every
 * reload would be an app you have to dismiss before you can work", which was
 * true of an overlay and is not true of a section.
 *
 * A module-level store rather than a framework one, and the reason is
 * structural: the two halves of this feature occupy two DIFFERENT slots —
 * `sidebar.footer.action` for the switch and `shell.overlay` for the page —
 * so no React context spans them and no owner-props channel connects them
 * (that channel runs from one owner to ITS occupants, and these two have
 * different owners).
 *
 * This is safe here for exactly the reason the same trick is NOT safe in
 * `ui-kit`: ui-kit is INLINED into each consuming plugin's bundle, so a
 * module-level value there is one copy per plugin and shares nothing. Both
 * readers here live in THIS plugin's single bundle, so they see one module
 * instance and one value. A reader in ANOTHER bundle — the chat result node —
 * reaches it through `workbench-service.ts` instead, for the same reason.
 *
 * **Only the section is remembered, never the project.** Which workspace was
 * being inspected is re-derived on load from the host's own
 * `recentWorkspaceId`, which is a live answer to "which project is this person
 * in"; a persisted id would outlive the workspace it names and pin the page to
 * a project that is no longer there.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/home-store
 */
/** What the workbench is showing: the section flag, and the project in view. */
export interface HomeState {
    readonly open: boolean;
    /** The workspace whose project is being inspected, when one is chosen. */
    readonly workspaceId: string | undefined;
}
/**
 * Subscribe to section changes; returns the unsubscribe.
 *
 * Exported because `workbench-service.ts` republishes it across bundles — a
 * consumer in another plugin cannot import this module and see the same
 * instance, so the service is the channel and this is what it carries.
 */
export declare function subscribeHome(listener: () => void): () => void;
/** Show the project section, optionally on a specific project. */
export declare function openHome(workspaceId?: string): void;
/** Go back to the conversation, remembering which project was being inspected. */
export declare function closeHome(): void;
/** Switch between the two sections — what the sidebar control does. */
export declare function toggleHome(): void;
/** Choose which project the workbench inspects. */
export declare function selectProject(workspaceId: string): void;
/**
 * Reset to the conversation with no project chosen, and forget the section.
 * Exists for tests, which share a module AND a storage.
 */
export declare function resetHome(): void;
/** Read the current state without subscribing. */
export declare function readHome(): HomeState;
/** Subscribe a component to the section state. */
export declare function useHome(): HomeState;
//# sourceMappingURL=home-store.d.ts.map