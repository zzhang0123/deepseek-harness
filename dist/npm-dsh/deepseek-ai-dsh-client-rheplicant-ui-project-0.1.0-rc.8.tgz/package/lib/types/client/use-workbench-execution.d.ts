/**
 * The execution view the workbench hands its panels.
 *
 * The same `ConsoleExecutionView` shape the console builds, so a panel cannot
 * tell which surface it is rendering in — which is what makes "both seats, one
 * selection" (`docs/project-model.md` §11.3) true rather than approximately
 * true.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/use-workbench-execution
 */
import type { ConsoleExecutionView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
/**
 * Project the selected execution for the workbench's panels.
 *
 * @param workspaceId - the project, or undefined when none is chosen.
 * @param executionId - the execution, or undefined when none is chosen.
 * @param nonce - bump to re-read the same execution.
 * @returns the view every panel receives through the slot's owner props.
 */
export declare function useWorkbenchExecution(workspaceId: string | undefined, executionId: string | undefined, nonce?: number): ConsoleExecutionView;
//# sourceMappingURL=use-workbench-execution.d.ts.map