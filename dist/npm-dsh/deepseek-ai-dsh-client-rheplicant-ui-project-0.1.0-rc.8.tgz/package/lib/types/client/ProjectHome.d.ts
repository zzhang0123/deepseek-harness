/**
 * The workbench: the archive surface, root-scoped, over one project's
 * tasks, inputs and executions (`docs/project-model.md` §6.0).
 *
 * **Why `shell.overlay` and not §6.0's `conversation.hero.workspace`.** The
 * design named the hero slot on the reasoning that it is root-scoped and shows
 * when no session is open. Both halves are true; what the doc did not record is
 * that the slot is a single-occupant POPOVER anchored to a WorkspaceChip
 * (`ConversationRoot.tsx` renders it inside `heroWorkspaceRow`, gated on
 * `open: pickerOpen`), already occupied by the shipped `WorkspacePicker`, and
 * carrying `replaceRisk: 'shadows-shipped-ui'`. Taking it would mean
 * reimplementing workspace picking AND re-declaring the
 * `conversation.hero.workspace.directoryFlow` child slot, or the directory
 * pickers lose their mount point and nobody can add a workspace any more.
 *
 * `shell.overlay` is the additive root-scoped seat — a list, `replaceRisk:
 * none`, no occupants, described by its own contract as "the additive seat for
 * a frame-wide surface of your own". It gives the workbench an actual page
 * instead of a dropdown, and shadows nothing. The layer is click-through by
 * default, so this page opts back into pointer events for ITSELF and for
 * nothing else — grabbing them for the whole layer would block the app
 * underneath for every other entry too.
 *
 * **This is a SECTION, not a modal (§20.2).** It used to draw its own backdrop,
 * bind Escape and declare `role="dialog"`, and all three were ours — the slot
 * asked for none of them. A modal says "deal with me first"; the project is not
 * an interruption to the conversation, it is the peer of it, and the frame
 * behind stays lit and usable. So: no backdrop, no Escape, a `region`
 * landmark rather than a dialog, and a switch rather than a close.
 *
 * The page is right-aligned within the layer on purpose. The sidebar is the
 * left column of the frame underneath, and leaving the slack on that side is
 * what keeps it visible and clickable while this section is up. The gutter is
 * sized to the shell's DEFAULT sidebar and can only ever be a default —
 * `ui-layout` writes the column width as an inline `grid-template-columns` on
 * the frame rather than publishing a custom property, so no rule here can
 * follow a resize. Which is why the switch back also lives in this page's own
 * header: that one is reachable whatever the geometry.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/ProjectHome
 */
import { type ReactNode } from 'react';
import type { PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createWorkbenchLayoutStore } from './layout-store.ts';
import type { TaskPanelOwnerProps } from './index.ts';
/** The workspace rows the shell hands every root-scoped occupant. */
interface WorkspaceRow {
    readonly workspaceId: string;
    readonly title: string;
    readonly path: string;
}
/**
 * What this occupant reads off the root-scope standard kit.
 *
 * `useStore`/`actions` are baked in by the framework because THIS entry's own
 * registration declares `store: createWorkbenchLayoutStore` — the same channel
 * `AppFrame` receives its layout store through. Their types derive from the
 * handle's own return type rather than a hand-written twin, so the declared
 * write set in `layout-store.ts` cannot drift out of sync with what a caller
 * here can actually invoke.
 */
type ProjectHomeProps = {
    useWorkspaces: <T>(selector: (state: {
        items: readonly WorkspaceRow[];
        recentWorkspaceId: string | undefined;
    }) => T) => T;
    /** Renders this entry's own `task.panel` grid. */
    renderSlot: (key: 'task.panel', owner: TaskPanelOwnerProps) => ReactNode;
} & PropsStore<ReturnType<typeof createWorkbenchLayoutStore>>;
export declare const ProjectHome: import("react").MemoExoticComponent<({ useWorkspaces, renderSlot, useStore, actions }: ProjectHomeProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=ProjectHome.d.ts.map