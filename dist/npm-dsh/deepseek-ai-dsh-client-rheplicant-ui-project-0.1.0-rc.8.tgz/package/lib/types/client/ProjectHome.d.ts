/**
 * The project home: the archive surface, root-scoped, over one project's
 * tasks, inputs and executions (`docs/project-model.md` §6.0).
 *
 * **Why `shell.overlay` and not §6.0's `conversation.hero.workspace`.** The
 * design named the hero slot on the reasoning that it is root-scoped and shows
 * when no session is open. Both halves are true; what the doc did not record is
 * that the slot is a single-occupant POPOVER anchored to a WorkspaceChip
 * (`ConversationRoot.tsx` renders it inside `heroWorkspaceRow`, gated on
 * `open: pickerOpen`), already occupied by the shipped `WorkspacePicker`, and
 * carrying `replaceRisk: 'shadows-shipped-ui'`. Taking it would mean
 * reimplementing workspace picking AND re-declaring the
 * `conversation.hero.workspace.directoryFlow` child slot, or the directory
 * pickers lose their mount point and nobody can add a workspace any more.
 *
 * `shell.overlay` is the additive root-scoped seat — a list, `replaceRisk:
 * none`, no occupants, described by its own contract as "the additive seat for
 * a frame-wide surface of your own". It gives the archive an actual page
 * instead of a dropdown, and shadows nothing. The layer is click-through by
 * default, so this panel opts back into pointer events; that is why the
 * backdrop is drawn here rather than assumed.
 *
 * The home is a CHOOSER, per §6.0: it has no default selection, and it never
 * renders analysis. Picking an execution here is how you find one; rendering
 * it is the console's job, in a session.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/ProjectHome
 */
/** The workspace rows the shell hands every root-scoped occupant. */
interface WorkspaceRow {
    readonly workspaceId: string;
    readonly title: string;
    readonly path: string;
}
/** What this occupant reads off the root-scope standard kit. */
interface ProjectHomeProps {
    readonly useWorkspaces: <T>(selector: (state: {
        items: readonly WorkspaceRow[];
        recentWorkspaceId: string | undefined;
    }) => T) => T;
}
export declare const ProjectHome: import("react").MemoExoticComponent<({ useWorkspaces }: ProjectHomeProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=ProjectHome.d.ts.map