/**
 * How far one TASK is from being DEFINED — read off the document as authored,
 * not off the project tree.
 *
 * `docs/project-model.md` §7 and §12. The companion to `task-maturity.ts`,
 * and deliberately not part of it: maturity answers *should I believe these
 * results* from evidence on disk, and every criterion here is a pure function
 * of the document's own text, which leaves nothing on disk at all. Folding
 * them together would re-create exactly the stage P7c deleted — one whose
 * evidence never reaches the tree, so it reads as "never validated" rather
 * than "not recorded here".
 *
 * **Three states, not two.** `unknown` means the check could not be run, and
 * it must never render as `unmet`: telling someone their document is wrong
 * when the truth is that nobody could ask is how a fine document gets edited.
 * The same discipline the stale flag has for the same reason.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/task-definition
 */
import type { ProjectDefinitionBody, ProjectTaskRow } from '@rheplicant/dsh-rheplicant';
/** How a criterion reads. */
export type DefinitionState = 'ok' | 'unmet' | 'unknown';
/** One of §7's four criteria. */
export interface DefinitionCriterion {
    readonly id: 'inputs' | 'document' | 'gates' | 'name';
    readonly label: string;
    readonly state: DefinitionState;
    readonly detail: string;
}
/** Why a check could not be made, when it could not. */
export type DefinitionProblem = 'loading' | 'unreachable' | 'refused';
/** Everything the checklist is derived from. */
export interface DefinitionInput {
    readonly task: ProjectTaskRow;
    /** The host's answer, absent while loading or when it could not be had. */
    readonly report: ProjectDefinitionBody | undefined;
    readonly problem: DefinitionProblem | undefined;
    /**
     * sha256 of the document currently ON SCREEN, or undefined when it could
     * not be hashed. Compared against {@link ProjectDefinitionBody.digest}.
     */
    readonly documentDigest: string | undefined;
}
/**
 * §7's four criteria for one task.
 *
 * @param input - the task, the host's answer, and the on-screen document's digest.
 * @returns the four criteria, in reading order.
 */
export declare function taskDefinition(input: DefinitionInput): readonly DefinitionCriterion[];
//# sourceMappingURL=task-definition.d.ts.map