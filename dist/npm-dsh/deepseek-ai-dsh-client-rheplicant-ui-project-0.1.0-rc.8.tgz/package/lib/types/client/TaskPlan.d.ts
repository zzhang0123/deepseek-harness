/**
 * How the inference is set up: which parameters are fitted, into what, and by
 * which step with which knobs.
 *
 * **The gap this closes was named by the user**: *"所有参数如何block的（哪些用
 * NUTS，哪些用GCR，如何循环的，循环多少次，等信息需要显示）"* — which
 * parameters go through which engine, how the loop is arranged, and how many
 * iterations. None of it was on screen. The Exits panel says which of the
 * eighteen exits a document declares and what each WRITES; nothing said what
 * any of them was doing, to which latent, for how long.
 *
 * Three joins, all read straight off the document:
 *
 * 1. **The parameters** — `inference.parameters:`, each with its `into:`
 *    targets and its prior. That is "which parameters", and `into` is what
 *    connects a latent to the operator the Model diagram lights.
 * 2. **The steps** — `runs:` in order, each with the knobs the document wrote.
 *    `nuts` shows its warmup and sample counts, `plan.sample` its blocks,
 *    `predict` the run it reuses. That is "which engine, how many iterations".
 * 3. **The order** — the steps are numbered, because `reuse:` makes them a
 *    chain rather than a set, and a reader following a `reuse:` backwards is
 *    reading the loop.
 *
 * **Nothing here interprets the grammar.** Knobs arrive as
 * `DeclaredRun.options`, verbatim and unlisted, because a hand-kept table of
 * knob names would be a grammar this repo does not own (§2.1) and would go
 * stale the first time upstream adds one. The cost is that the panel cannot
 * order or explain them; the benefit is that what a reader sees is exactly
 * what they wrote.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/TaskPlan
 */
import type { DeclaredParameter, DocumentRuns } from '@rheplicant/dsh-rheplicant';
export declare const TaskPlan: import("react").MemoExoticComponent<({ runs, parameters }: {
    readonly runs: DocumentRuns;
    readonly parameters: readonly DeclaredParameter[];
}) => import("react").JSX.Element>;
//# sourceMappingURL=TaskPlan.d.ts.map