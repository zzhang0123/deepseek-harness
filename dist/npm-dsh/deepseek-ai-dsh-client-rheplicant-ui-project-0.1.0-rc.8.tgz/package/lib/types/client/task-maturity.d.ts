/**
 * How far one TASK has got toward being trustworthy — read off the project
 * tree, not off any conversation.
 *
 * `docs/project-model.md` §11.4. The half of the old loop rail that belongs to
 * the task: it survives every session, because its evidence is on disk. The
 * other half — what THIS conversation just did — stays in the console, reading
 * the session log, and answers a different question.
 *
 * **Four stages, not five.** The old rail had a `validate` segment, and there
 * is deliberately none here: a validate that ran without publishing leaves
 * nothing on disk, so the stage would sit permanently blank and read as "this
 * task has never been validated" rather than "that is not recorded in the
 * tree". A stage that cannot be answered is worse than a stage that is absent.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/task-maturity
 */
import type { ConsoleExecutionView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
import type { ProjectExecutionRow, ProjectTaskRow } from '@rheplicant/dsh-rheplicant';
/** How a stage reads. Shared vocabulary with the console's own rail. */
export type MaturityState = 'ok' | 'warn' | 'error' | 'idle';
/** One stage of a task's maturity. */
export interface MaturityStage {
    readonly id: 'document' | 'runs' | 'gates' | 'diagnostics';
    readonly label: string;
    readonly state: MaturityState;
    readonly detail: string;
    /**
     * True when the authored document no longer digests to what ran, false when
     * it still does, and ABSENT when the comparison could not be made at all.
     *
     * Three values, not two: an execution whose sidecar recorded no digest, or a
     * document that could not be hashed, must not read as "changed" — that would
     * mark a perfectly fresh result stale forever.
     */
    readonly stale?: boolean;
}
/** Everything the maturity rail is derived from. */
export interface MaturityInput {
    readonly task: ProjectTaskRow;
    /** The task's newest execution, absent when it has never run. */
    readonly newest: ProjectExecutionRow | undefined;
    /** That execution projected, absent when there is none to project. */
    readonly view: ConsoleExecutionView | undefined;
    /** sha256 of the authored document, absent when it could not be computed. */
    readonly documentDigest: string | undefined;
}
/**
 * The stages of one task's maturity.
 *
 * @param input - the task, its newest execution, that execution's projection,
 *   and the authored document's digest.
 * @returns the four stages, in reading order.
 */
export declare function taskMaturity(input: MaturityInput): readonly MaturityStage[];
//# sourceMappingURL=task-maturity.d.ts.map