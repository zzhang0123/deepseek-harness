/**
 * The definition checklist: how far this task is from being one you can run.
 *
 * `docs/project-model.md` §7 and §12. The workbench's OTHER rail — maturity
 * asks "should I believe these results" of the tree, this asks "is this a
 * task at all" of the document. Labelled by its source on screen for the same
 * reason P7c labelled the activity strip: unlabelled, a rail reads as a
 * statement about whatever surface it happens to sit on.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/TaskDefinition
 */
import { type DefinitionInput } from './task-definition.ts';
/** Everything the checklist needs, passed straight through to the selector. */
export type TaskDefinitionProps = DefinitionInput;
export declare const TaskDefinition: import("react").MemoExoticComponent<(props: TaskDefinitionProps) => import("react").JSX.Element>;
//# sourceMappingURL=TaskDefinition.d.ts.map