/**
 * The project home's read of one project, over the host's own route.
 *
 * `docs/project-model.md` §6.0. The console's own client
 * (`ui-console/project-api-client.ts`) asks by SESSION, because it is always
 * inside a conversation. The project home is shown exactly when no session is
 * open, so it asks by WORKSPACE id — the uuid the host minted and handed the
 * browser through the workspace list. Same trust boundary, different handle:
 * neither surface names a directory, so neither can widen the host's reachable
 * set beyond the sessions and workspaces the host already registered.
 *
 * Everything here degrades rather than throws. A composition without the route
 * plugin answers 404, and the home must say "this project is not readable from
 * here" rather than take its slot down — `undefined` is that state, and it is
 * a different fact from an empty project.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/project-overview-client
 */
import type { ProjectExecutionRow, ProjectInputRow, ProjectOverviewBody, ProjectTaskRow } from '@rheplicant/dsh-rheplicant';
/**
 * Everything one project holds and has run.
 *
 * @param workspaceId - the workspace the host minted an id for. The host
 *   resolves the directory from it; no path is ever sent.
 * @param signal - abort when the selection changes or the home closes.
 * @returns the overview, or `undefined` when the project cannot be read from
 *   here — a composition without the route, an id the registry dropped, or a
 *   body that did not decode.
 */
export declare function fetchProjectOverview(workspaceId: string, signal?: AbortSignal): Promise<ProjectOverviewBody | undefined>;
export type { ProjectExecutionRow, ProjectInputRow, ProjectOverviewBody, ProjectTaskRow };
//# sourceMappingURL=project-overview-client.d.ts.map