/**
 * The Model section's two sources, and the guards between them.
 *
 * `docs/project-model.md` §28.1. The workbench used to draw the canonical
 * graph AND carry a `signal-path` panel drawing the selected execution's —
 * two copies of one picture, in two different fixed themes, with neither
 * saying which it was. The panel is gone; the comparison it was accidentally
 * providing lives here, stated, over ONE renderer.
 *
 * It is a hook of its own for the reason the review that prompted it gave:
 * this is forty lines of state, a fetch and three guards, and inlining it put
 * `ProjectHome` within twenty lines of this repo's own file ceiling.
 *
 * @module @rheplicant/dsh-rheplicant-ui-project/client/use-model-source
 */
import type { ProjectExecutionRow, ProjectTaskRow } from '@rheplicant/dsh-rheplicant';
import type { ModelSourceView } from './TaskModel.tsx';
import { type DocumentProjectionState } from './use-document-projection.ts';
/** What the Model panel needs in order to render either source. */
export interface ModelSourceState {
    /** The as-run projection, IDLE until somebody asks for it. */
    readonly asRun: DocumentProjectionState;
    /** True when the as-run projection is the one to draw. */
    readonly comparing: boolean;
    /** What `TaskModel` renders its switch from. */
    readonly source: ModelSourceView;
}
/** Everything the two sources are derived from. */
export interface ModelSourceInput {
    readonly workspaceId: string | undefined;
    readonly taskPath: string | undefined;
    readonly executionId: string | undefined;
    readonly nonce: number;
    /** The selected task's row, absent when the selection names no listed task. */
    readonly task: ProjectTaskRow | undefined;
    /** The selected execution's row, absent when it is not in this listing. */
    readonly execution: ProjectExecutionRow | undefined;
    /** sha256 of the authored document, absent when it could not be computed. */
    readonly documentDigest: string | undefined;
}
/**
 * Resolve which model the section is showing, and whether it may compare.
 *
 * @param input - the selection, the two rows behind it, and the digest.
 * @returns the projection, the flag, and the switch's own view.
 */
export declare function useModelSource(input: ModelSourceInput): ModelSourceState;
//# sourceMappingURL=use-model-source.d.ts.map