/** Package-owned invariant companion for `@rheplicant/dsh-rheplicant-ui-project`. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "rheplicant-ui-project-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map