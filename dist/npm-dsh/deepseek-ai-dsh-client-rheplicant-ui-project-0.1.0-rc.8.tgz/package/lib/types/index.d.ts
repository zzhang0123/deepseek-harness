/** Node half of the rheplicant ui-project client plugin. The browser half is the whole feature. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map