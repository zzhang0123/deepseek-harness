/**
 * Business Definitions folding the three durable rheplicant events into the
 * `rheplicant-loop` conversation-view target. One Definition per event type,
 * each a one-shot fact (matches `trajectory-message-definitions.ts`'s
 * `trajectoryInboxDefinition`/`trajectoryMessageDefinition` shape: `id =
 * String(event.seq)`, always `role: 'start'`, `update` a no-op) — every
 * occurrence is its own Context, never merged with an earlier one. The
 * builder (`loop-snapshot-builder.ts`) is what folds many one-shot facts down
 * to "the latest of each kind".
 * @module @rheplicant/dsh-rheplicant-ui-loop/client/loop-definitions
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Register the three loop-fact Definitions.
 * @param ctx - Plugin context receiving the Definitions.
 */
export declare function registerLoopDefinitions(ctx: Context): void;
//# sourceMappingURL=loop-definitions.d.ts.map