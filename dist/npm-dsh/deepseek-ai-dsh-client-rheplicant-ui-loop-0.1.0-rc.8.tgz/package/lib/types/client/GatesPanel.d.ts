import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { type LoopExecutionView, type PanelLayoutView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
interface GatesPanelProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    /**
     * The execution being shown (owner prop), so the POST-FLIGHT findings below
     * belong to the execution this surface is addressing rather than to whatever
     * the open conversation last ran.
     *
     * This panel read the session log alone until §20.4 made the workbench's
     * grid the only seat — and the workbench hands its panels an EMPTY
     * conversation on purpose (§11.5), so reading the log there answered "no
     * gates evidence yet" for every execution, including ones whose tree records
     * a refusal. The priced CHECKS below still come from the log, because they
     * are a `rheplicant/gates` fact and no execution's tree carries them; the
     * panel says so rather than leaving the absence unexplained.
     */
    execution?: LoopExecutionView;
    /** Panel layout state (owner prop — see ProjectHome's doc comment). Absent when not rendered through a panel grid (e.g. a unit test): renders un-collapsed, always visible. */
    layout?: PanelLayoutView;
}
export declare const GatesPanel: import("react").MemoExoticComponent<({ useSession, layout, execution }: GatesPanelProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=GatesPanel.d.ts.map