import type { LoopExecutionState } from './use-loop-execution.ts';
interface ProjectHeaderProps {
    /** The console's selection state — see `useLoopExecution`. */
    execution: LoopExecutionState;
}
export declare const ProjectHeader: import("react").MemoExoticComponent<({ execution }: ProjectHeaderProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=ProjectHeader.d.ts.map