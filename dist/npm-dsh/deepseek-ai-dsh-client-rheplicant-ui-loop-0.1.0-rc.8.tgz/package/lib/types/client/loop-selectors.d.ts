/**
 * Pure derivation of the LoopRail's five stage verdicts (and Validate's
 * four-pass breakdown) from one `LoopSnapshot`. Kept separate from
 * `LoopRail.tsx` so the honesty rules — what the wire can and cannot support
 * per stage — are readable and reviewable on their own, the same split
 * `run-selectors.ts` draws for the workbench panels.
 *
 * WIRE HONESTY NOTES (why some states can never appear, or only appear under
 * a narrower condition than a first reading of the four-pass rule suggests):
 * - `author` only ever renders `ok`/`idle`: the wire carries no authoring
 *   failure signal (a document either exists on the latest event or it
 *   doesn't), so `warn`/`error` are structurally unreachable here.
 * - `axes` only ever renders `ok`/`unknown`: the compute service documents
 *   exactly one build-stage failure code (`BUILD_FAILED`, on `built`); there
 *   is no equivalent "axes failed" code, so this pass can never honestly
 *   render `error` — see `axesBuiltPasses` below.
 * - `axes`/`built` render `ok` ONLY when every run in the outcome succeeded
 *   (`status === 'ok'`) or the one documented failure code (`BUILD_FAILED`)
 *   fires. A run that failed for any OTHER reason is genuinely ambiguous
 *   evidence: the wire gives no way to tell "failed after axes/built
 *   succeeded, during the actual compute" apart from "failed for an
 *   unreported reason before either finished" — so both passes render
 *   `unknown` rather than assume the optimistic reading. This is the
 *   dominant source of `unknown` passes in practice: an ordinary compute
 *   failure (not a build failure, not a full success) leaves axes/built
 *   with no honest verdict.
 * - `pending` (of the five-value stage-state enum) is never produced by any
 *   stage: every durable rheplicant event fires only once a call has
 *   settled, so the wire has no "in flight" signal for validate/gates/run to
 *   render against. The state exists for forward-compatibility with the
 *   enum's declared range, not because today's wire can reach it.
 * - `diagnostics`' r_hat check reads BOTH the scalar `RunDiagnostics.rhat`
 *   AND the per-latent `RunDiagnostics.mcmc` bag, at the ONE shared
 *   threshold `ui-kit` owns (`RHAT_WARN_ABOVE`) — a multi-latent NUTS run
 *   commonly reports r_hat/n_eff ONLY per-latent, with no scalar `rhat` at
 *   all, so reading the scalar alone used to render a false `ok` for a run
 *   whose worst latent was well over threshold. There is still only ONE warn
 *   tier here, scalar or per-latent: a bad r_hat never escalates this stage
 *   to `error` (only `divergences > 0` or `converged === false` do) — mixing
 *   the two paths does not invent a new severity, it only widens which
 *   fields participate in the existing one.
 * @module @rheplicant/dsh-rheplicant-ui-loop/client/loop-selectors
 */
import type { LoopTask } from './loop-tasks.ts';
export type StageId = 'author' | 'validate' | 'gates' | 'run' | 'diagnostics';
export type StageState = 'ok' | 'warn' | 'error' | 'pending' | 'idle';
export type PassId = 'pre-flight' | 'axes' | 'built' | 'post-flight';
export type PassState = 'ok' | 'warn' | 'error' | 'unknown';
export interface PassInfo {
    readonly id: PassId;
    readonly state: PassState;
}
export interface StageInfo {
    readonly id: StageId;
    readonly label: string;
    readonly state: StageState;
    readonly detail: string;
    /** `[data-panel]` target this stage scrolls into view when clicked; absent = no click target. */
    readonly panelTarget?: string;
    /** Validate only: the four-pass breakdown. */
    readonly passes?: readonly PassInfo[];
    /** Gates only: whether any check is in a skip/auto_skip state (the "stale purple" marker). */
    readonly stale?: boolean;
}
export declare function authorStage(snapshot: LoopTask): StageInfo;
export declare function validateStage(snapshot: LoopTask): StageInfo;
export declare function gatesStage(snapshot: LoopTask): StageInfo;
export declare function runStage(snapshot: LoopTask): StageInfo;
export declare function diagnosticsStage(snapshot: LoopTask): StageInfo;
/** Every stage in fixed display order: Author, Validate, Gates, Run, Diagnostics. */
export declare function loopStages(snapshot: LoopTask): readonly StageInfo[];
//# sourceMappingURL=loop-selectors.d.ts.map