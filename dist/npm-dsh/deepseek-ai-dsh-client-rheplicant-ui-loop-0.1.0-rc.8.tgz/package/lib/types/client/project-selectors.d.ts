/**
 * What the console header says, derived from one execution reference.
 *
 * `docs/project-model.md` §6.1. Every field here comes out of the published
 * path and the execution id, both of which the run event already carries — the
 * header asks the host for nothing. That is not an optimisation: a header that
 * needed a round trip would go blank exactly when results were unreachable,
 * which is the state it most needs to be able to describe.
 *
 * @module @rheplicant/dsh-rheplicant-ui-loop/client/project-selectors
 */
import type { ProjectExecutionRow } from '@rheplicant/dsh-rheplicant';
import type { LoopExecutionRef } from './loop-contract.ts';
/**
 * The project's own name: the directory holding `results/`.
 * @param resultsPath - an execution's absolute published path.
 * @returns the project directory's basename, or undefined when the path does
 *   not look like a published tree.
 */
export declare function projectName(resultsPath: string | undefined): string | undefined;
/**
 * The task segment: everything between `results/` and the execution directory.
 * @param resultsPath - an execution's absolute published path.
 * @returns e.g. `tasks/global-signal-fit`, or undefined when unreadable.
 */
export declare function taskOf(resultsPath: string | undefined): string | undefined;
/**
 * The published path as the user would type it: project-relative, trailing slash.
 * @param resultsPath - an execution's absolute published path.
 * @returns e.g. `results/tasks/global-signal-fit/20260822T134501Z-…/`.
 */
export declare function projectRelativePath(resultsPath: string | undefined): string | undefined;
/**
 * The wall-clock time an execution id was minted, in UTC.
 *
 * Read off the id rather than a file's mtime: the id is what the run was named,
 * and an mtime describes when bytes last moved, which is a different fact.
 *
 * @param executionId - `<UTC compact>-<digest8>-<random6>`.
 * @returns `14:45:01`, or undefined for an id that carries no stamp.
 */
export declare function executionTime(executionId: string): string | undefined;
/**
 * The date an execution id was minted, in UTC.
 * @param executionId - `<UTC compact>-<digest8>-<random6>`.
 * @returns `2026-08-22`, or undefined for an id that carries no stamp.
 */
export declare function executionDate(executionId: string): string | undefined;
/**
 * The executions a picker offers: newest first.
 * @param executions - the snapshot's list, oldest first.
 * @returns a new array, newest first; never the input array.
 */
export declare function newestFirst(executions: readonly LoopExecutionRef[]): LoopExecutionRef[];
/**
 * One execution as the header shows it, from either source.
 *
 * The two sources report DIFFERENT things and are kept apart on purpose. This
 * session's log knows whether a run inside the execution failed; the tree knows
 * whether the publication itself was refused. An execution can perfectly well
 * publish `ok` and contain a failed run, so folding them into one `status`
 * would make the header claim something neither source said.
 */
export interface HeaderExecution {
    readonly executionId: string;
    readonly task?: string;
    readonly path?: string;
    readonly transport?: string;
    /** From this session's log: did any run inside it fail? */
    readonly runsFailed?: boolean;
    /** From the tree: how the publication itself ended. */
    readonly publication?: 'ok' | 'refused' | 'error';
    /** False for an execution some other session produced. */
    readonly fromThisSession: boolean;
    /** The producing session, when the tree's sidecar recorded one. */
    readonly sessionId?: string;
}
/**
 * The list the picker offers: the project's executions when the host can be
 * reached, this session's own when it cannot.
 *
 * An execution this session produced but the project listing does not carry —
 * an inline run that published nothing, or one whose tree has since been
 * pruned — is still offered. Dropping it would make a run vanish from the
 * console because its results moved, which is the failure this design exists to
 * prevent.
 *
 * @param own - this session's executions, oldest first.
 * @param project - the host's project-wide listing, or undefined when the
 *   project is not readable from here.
 * @returns one row per execution, newest first.
 */
export declare function mergeExecutions(own: readonly LoopExecutionRef[], project: readonly ProjectExecutionRow[] | undefined): HeaderExecution[];
//# sourceMappingURL=project-selectors.d.ts.map