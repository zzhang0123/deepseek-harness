/**
 * Browser plugin for this conversation's own view of the project: a
 * session-header control holding the project header and the activity rail,
 * plus the `rheplicant-loop` conversation-view target both read, plus the
 * `gates` occupant of the workbench's grid.
 *
 * **This package lost both of the seats it was named for, and has now lost the
 * name too** (`ui-console` → `ui-loop`, 2026-08-26). It used to DECLARE
 * `console.panel`, a child grid every viz plugin injected into, and §20.4
 * removed it: the same occupants were registered twice — here and in
 * ui-project's `task.panel` — and the panels belong to the project, not to
 * whichever conversation happens to be open. Then §23 removed the "Console"
 * `conversation.view` tab itself, because what §20.4 left behind was a whole
 * tab holding a header and one rail, and you had to leave the conversation to
 * read what the conversation had done. Both declarations are gone rather than
 * left in place and unrendered, so a new panel has one seat to choose and no
 * way to end up in the wrong one.
 *
 * **Why `loop` and not `session-activity`**, the other candidate
 * (`docs/surface-model.md` §9.5 lists "session activity" first): the activity
 * rail is only one of the three things registered below, and `GatesPanel`
 * renders in the WORKBENCH, where no session is involved at all. What all
 * three have in common is §19's loop — *a loop belongs to a task*, the
 * validate → gates → run cycle — which is the sense `surface-model.md` §1.1
 * explicitly preserves while exiling the other two ("periodic repetition" is a
 * Trigger; "the agentic loop" is runtime behaviour). The package's own
 * vocabulary had already gone there: `loop-contract`, `loop-definitions`,
 * `loop-rail`, `loop-selectors`, `loop-snapshot-builder`, `loop-tasks`,
 * `LoopRail`, and the `rheplicant-loop` conversation-view target itself.
 *
 * The word "console" survives in PROSE here and in other packages, describing
 * a surface that no longer exists. Retiring it there is `surface-model.md`
 * §9.5's own programme and a different commit; this one moved identifiers.
 * @module @rheplicant/dsh-rheplicant-ui-loop/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export type { LoopContribution, LoopConversationViewNode, LoopGatesEntry, LoopRunEntry, LoopSnapshot, LoopValidateEntry, } from './loop-contract.ts';
export { loopViewDefinition } from './loop-snapshot-builder.ts';
export { soleTask, type LoopTask } from './loop-tasks.ts';
export { chooseExecution, proposeExecution, resetLocalSelection, setSelectionSource, useProjectSelection, } from './selection-bridge.ts';
export type { ProjectSelection, SelectionPatch, SelectionSource } from './selection-bridge.ts';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map