/**
 * One conversation's rheplicant work, GROUPED BY THE TASK it was about.
 *
 * `docs/project-model.md` §19. The projection used to fold every contribution
 * to "the latest of each kind" with no task discrimination at all — its own
 * comment said so. A conversation that validated task A and then ran task B
 * therefore rendered A's Validate beside B's Run, as one coherent loop. Not
 * merely "session looks one-to-one with task": a loop FABRICATED out of
 * unrelated work, which is worse than the coupling §11 set out to remove.
 *
 * The fix is at the level the fault lives on. `taskPath` has been on every
 * durable event since P1, and the client contract discarded it for two of the
 * three kinds — so nothing downstream COULD group correctly. A loop belongs
 * to a task; this makes that structural.
 *
 * @module @rheplicant/dsh-rheplicant-ui-loop/client/loop-tasks
 */
import type { LoopContribution, LoopExecutionRef, LoopGatesEntry, LoopRunEntry, LoopValidateEntry } from './loop-contract.ts';
/** One task's loop, as this conversation exercised it. */
export interface LoopTask {
    /**
     * The task these facts are about, or undefined for work not filed under one.
     *
     * An inline document has no path to group by, so every inline contribution
     * shares one bucket. That is the best available answer and it is honest:
     * folding it into a named task would attribute scratch work to a file that
     * never ran it.
     */
    readonly taskPath?: string;
    readonly validate?: LoopValidateEntry;
    readonly gates?: LoopGatesEntry;
    readonly run?: LoopRunEntry;
    /** This task's executions in this conversation, oldest first. */
    readonly executions: readonly LoopExecutionRef[];
    /** The greatest `seq` among this task's facts. */
    readonly latestSeq: number;
}
/**
 * Group one conversation's contributions by the task each was about.
 *
 * @param contributions - every matched validate/gates/run fact, any order.
 * @returns one entry per task, most recently active first, so the task the
 *   conversation is working on now leads.
 */
export declare function groupByTask(contributions: readonly LoopContribution[]): readonly LoopTask[];
/**
 * The one task a conversation touched, or undefined when it is not one.
 *
 * For a LOG FALLBACK. A conversation that touched several tasks has several
 * loops, and the log cannot say which one a panel is showing — so a caller
 * that would otherwise guess declines instead. The same rule `runsToRender`
 * applies to an execution it cannot read: an answer about the wrong task is
 * worse than no answer.
 *
 * **The implementation lives in ui-kit**, re-exported here so this package's
 * surface is unchanged. `SignalPathPanel` (ui-analysis) needs the same rule,
 * and importing it FROM here as a value made that package's client bundle
 * unbuildable — the purity gate refuses cross-plugin value imports, and the
 * failure was invisible because `test:web:built` serves the last bundle a
 * package emitted. ui-kit is the layer that may be inlined into both.
 */
export { soleTask } from '@rheplicant/dsh-rheplicant-ui-kit/client';
//# sourceMappingURL=loop-tasks.d.ts.map