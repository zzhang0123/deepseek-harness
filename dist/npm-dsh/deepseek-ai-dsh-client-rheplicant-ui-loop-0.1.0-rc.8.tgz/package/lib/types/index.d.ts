/** Node half of the rheplicant ui-loop client plugin. All of its behaviour is in the browser half. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map