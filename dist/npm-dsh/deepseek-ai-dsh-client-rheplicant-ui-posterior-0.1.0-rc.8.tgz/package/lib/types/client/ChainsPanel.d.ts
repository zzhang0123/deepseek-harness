import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { type PanelLayoutView, type ConsoleExecutionView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
interface ChainsPanelProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    /** Panel layout state (owner prop — see ui-project's ProjectHome doc comment). Absent when not rendered through a panel grid: renders un-collapsed, always visible. */
    layout?: PanelLayoutView;
    /** The execution the console is showing (owner prop). Absent outside the console shell. */
    execution?: ConsoleExecutionView;
}
export declare const ChainsPanel: import("react").MemoExoticComponent<({ useSession, layout, execution }: ChainsPanelProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=ChainsPanel.d.ts.map