import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { type PanelLayoutView, type LoopExecutionView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
interface ReconstructionPanelProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    /** Panel layout state (owner prop — see ui-project's ProjectHome doc comment). Absent when not rendered through a panel grid (e.g. a unit test): renders un-collapsed, always visible. */
    layout?: PanelLayoutView;
    /** The execution the workbench is showing (owner prop). Absent outside the workbench shell. */
    execution?: LoopExecutionView;
}
export declare const ReconstructionPanel: import("react").MemoExoticComponent<({ useSession, layout, execution }: ReconstructionPanelProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=ReconstructionPanel.d.ts.map