/**
 * Browser plugin for the posterior + chains panels. Injects into the
 * `task.panel` slot declared by ui-project — the separate-viz-plugin
 * contract: this package reads nothing but the project's own selection, and
 * does not re-run compute. Three registrations, one plugin: posterior
 * (per-latent marginals + the corner plot), chains (raw per-latent trace/band
 * charts), reconstruction (the quantity the posterior implies, as a
 * waterfall). Each has its OWN `inject` call and they render in that order.
 * @module @rheplicant/dsh-rheplicant-ui-posterior/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map