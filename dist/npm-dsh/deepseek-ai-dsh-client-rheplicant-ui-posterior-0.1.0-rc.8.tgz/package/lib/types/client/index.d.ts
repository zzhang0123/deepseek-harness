/**
 * Browser plugin for the posterior + chains panels. Injects into the
 * `task.panel` slot declared by ui-project — the separate-viz-plugin
 * contract: this package reads nothing but the project's own selection, and
 * does not re-run compute. Two registrations, one plugin: posterior first
 * (per-latent marginals + the corner plot), chains second (raw per-latent
 * trace/band charts) — the second `inject` call runs after the first, so
 * chains renders after posterior in the grid.
 * @module @rheplicant/dsh-rheplicant-ui-posterior/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map