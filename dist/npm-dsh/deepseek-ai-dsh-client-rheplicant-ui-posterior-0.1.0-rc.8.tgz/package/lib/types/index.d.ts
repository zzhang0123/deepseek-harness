/** Node half of the rheplicant ui-posterior client plugin. The browser half injects the panel. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map