/** Node half of the rheplicant ui-spectrum client plugin. The browser half injects the panel. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map