import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { type ConsolePanelLayoutView, type ConsoleExecutionView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
interface SpectrumPanelProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    /** Console layout state (owner prop — see ui-console's ConsoleView doc comment). Absent when not rendered through the console shell (e.g. a unit test): renders un-collapsed, always visible. */
    layout?: ConsolePanelLayoutView;
    /** The execution the console is showing (owner prop). Absent outside the console shell. */
    execution?: ConsoleExecutionView;
}
export declare const SpectrumPanel: import("react").MemoExoticComponent<({ useSession, layout, execution }: SpectrumPanelProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=SpectrumPanel.d.ts.map