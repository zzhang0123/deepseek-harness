/**
 * Browser plugin for the spectrum panel. Injects into the `task.panel` slot
 * declared by ui-project — the separate-viz-plugin contract: this package reads
 * nothing but the project's own selection, and does not re-run compute.
 * @module @rheplicant/dsh-rheplicant-ui-spectrum/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map