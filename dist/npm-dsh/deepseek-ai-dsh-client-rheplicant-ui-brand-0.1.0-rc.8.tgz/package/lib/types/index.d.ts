/** Node half of the rheplicant ui-brand client plugin (empty apply). */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map