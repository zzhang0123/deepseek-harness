import type { HeroBrandMarkOwnerProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { SidebarBrandMarkOwnerProps } from '@deepseek-ai/dsh-client-ui-sidebar/client';
type RheplicantBrandMarkProps = HeroBrandMarkOwnerProps & SidebarBrandMarkOwnerProps;
/** Render the rheplicant mark (a plain diamond glyph). */
export declare function RheplicantBrandMark({ size, className }: RheplicantBrandMarkProps): import("react").JSX.Element;
/** Render the rheplicant name wordmark. */
export declare function RheplicantBrandName(): import("react").JSX.Element;
export {};
//# sourceMappingURL=Brand.d.ts.map