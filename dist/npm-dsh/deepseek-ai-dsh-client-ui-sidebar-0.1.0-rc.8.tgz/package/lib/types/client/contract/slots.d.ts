/**
 * Sidebar slot contract: the registrant-side props composition for the
 * layout-owned `sidebar` slot, plus the holes this shell declares. The shell
 * owns column geometry (fold state machine, brand row, New Session);
 * everything between the section header and the list bottom is the
 * `sidebar.workspaces` registrant's (ui-workspace), and the foot is the
 * `sidebar.settings` registrant's (ui-settings), followed by optional footer
 * actions in `sidebar.footer.action`.
 */
import type { PropsLocale, PropsRenderSlots, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { WorkspaceId } from '@deepseek-ai/dsh-client-runtime/client';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /**
         * Brand mark rendered in the expanded brand row and collapsed rail.
         * Declared by this package's `sidebar` entry; deployments may replace
         * the shell's fish fallback without replacing the surrounding controls.
         */
        'sidebar.brand.mark': {
            kind: 'single';
            scope: 'root';
            owner: SidebarBrandMarkOwnerProps;
        };
        /**
         * Brand name rendered beside the expanded mark. Declared by this
         * package's `sidebar` entry; the shell supplies a generic text fallback.
         */
        'sidebar.brand.name': {
            kind: 'single';
            scope: 'root';
            owner: SidebarBrandNameOwnerProps;
        };
        /**
         * The workspace/session browsing region: section header, search, the
         * grouped/flat session list, and every workspace dialog. Declared by this
         * package's 'sidebar' entry (declaring is claiming); ui-workspace
         * registers the browser.
         */
        'sidebar.workspaces': {
            kind: 'single';
            scope: 'root';
            owner: SidebarSectionOwnerProps;
        };
        /**
         * The settings seat at the sidebar foot. Declared by this package's
         * 'sidebar' entry; ui-settings registers its trigger row + modal panel.
         * The sidebar passes only its column state — it holds no settings state.
         */
        'sidebar.settings': {
            kind: 'single';
            scope: 'root';
            owner: SidebarSettingsOwnerProps;
        };
        /**
         * Primary navigation entries between New Session and the browsing region:
         * one row per top-level surface a deployment adds. Declared by this
         * package's 'sidebar' entry; each entry receives only the column state and
         * owns its own row, exactly as a footer action does.
         *
         * WHY THIS EXISTS BESIDE `sidebar.footer.action`. The foot was the only
         * additive seat in this column, so anything a deployment added — including
         * a switch to a whole peer surface — had to sit under Settings, below the
         * session list, reading as a utility rather than as a place. The two seats
         * differ in what they mean, not in what they can hold: the foot is for
         * utilities beside Settings, this is for destinations beside New Session.
         */
        'sidebar.nav': {
            kind: 'list';
            scope: 'root';
            owner: SidebarNavOwnerProps;
        };
        /**
         * Optional actions beside Settings at the sidebar foot. Declared by this
         * package's 'sidebar' entry; each action receives only the column state.
         */
        'sidebar.footer.action': {
            kind: 'list';
            scope: 'root';
            owner: SidebarFooterActionOwnerProps;
        };
    }
}
/** Column state supplied to each primary-navigation occupant. */
export interface SidebarNavOwnerProps {
    /** False on the compact rail, where a row has no room for its label. */
    wide: boolean;
}
/** Geometry supplied to the sidebar brand-mark occupant. */
export interface SidebarBrandMarkOwnerProps {
    /** Requested square edge in pixels. */
    size: number;
}
/** Empty owner share for the sidebar brand-name occupant. */
export interface SidebarBrandNameOwnerProps {
    /** Marker field: the occupant owns its own content and width. */
    children?: never;
}
/**
 * Owner share of the browser hole — the only facts crossing the shell/region
 * boundary. Business data and actions arrive through the region's own inject.
 */
export interface SidebarSectionOwnerProps {
    /** Shell fold-state output: wide renders the full browser, rail the icon column. */
    wide: boolean;
    /** Rail icons request expansion; the browser rides the wide flip for focus. */
    expandSidebar: () => void;
}
/**
 * Owner share of the sidebar settings seat: the column display state the
 * occupant's trigger row must render against (wide row vs rail icon).
 */
export interface SidebarSettingsOwnerProps {
    /** Whether the sidebar renders wide content (false = 56px rail). */
    wide: boolean;
}
/** Owner share of an action rendered beside Settings at the sidebar foot. */
export interface SidebarFooterActionOwnerProps {
    /** Whether the sidebar renders wide content (false = 56px rail). */
    wide: boolean;
}
/**
 * Registrant-private injected share (arrives via the register inject
 * factory). The shell keeps only its own controls: starting a Session from
 * the New Session button and toggling the column.
 */
export type SidebarRootInjected = {
    /**
     * Start a New Session: with a workspace, reuse-or-create its blank session
     * and open it; without one, inherit the current Session Workspace, then the
     * recent Workspace, or clear into the New Session pure view when none exist.
     */
    startSession: (workspaceId?: WorkspaceId) => void;
    /** Toggle the sidebar column through the layout service. */
    toggleSidebar: () => void;
};
/**
 * Full component props: layout owner state/actions plus the declared holes'
 * render shares, this package's injected callbacks, and the standard locale
 * seat. No store is registered.
 */
export type SidebarRootComponentProps = PropsRuntime<'sidebar'> & PropsRenderSlots<'sidebar.brand.mark' | 'sidebar.brand.name' | 'sidebar.workspaces' | 'sidebar.settings' | 'sidebar.nav' | 'sidebar.footer.action'> & SidebarRootInjected & PropsLocale<'sidebar'>;
//# sourceMappingURL=slots.d.ts.map