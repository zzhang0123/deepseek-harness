/** Node half of the rheplicant ui-console client plugin. The browser half declares the panel grid slot. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map