/**
 * Browser plugin for this conversation's own view of the project: a
 * session-header control holding the project header and the activity rail,
 * plus the `rheplicant-loop` conversation-view target both read, plus the
 * `gates` occupant of the workbench's grid.
 *
 * **This package has now lost both of the seats it was named for.** It used to
 * DECLARE `console.panel`, a child grid every viz plugin injected into, and
 * §20.4 removed it: the same occupants were registered twice — here and in
 * ui-project's `task.panel` — and the panels belong to the project, not to
 * whichever conversation happens to be open. Then §23 removed the "Console"
 * `conversation.view` tab itself, because what §20.4 left behind was a whole
 * tab holding a header and one rail, and you had to leave the conversation to
 * read what the conversation had done. Both declarations are gone rather than
 * left in place and unrendered, so a new panel has one seat to choose and no
 * way to end up in the wrong one.
 *
 * The package NAME still says console, and the word is retiring
 * (`docs/surface-model.md` §9.5). Renaming it moves a bundle id, a module-table
 * row and every mirror — the same trade the Workbench rename declined for
 * identifiers — so it waits for a commit that is about that and nothing else.
 * @module @rheplicant/dsh-rheplicant-ui-console/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export type { LoopContribution, LoopConversationViewNode, LoopGatesEntry, LoopRunEntry, LoopSnapshot, LoopValidateEntry, } from './loop-contract.ts';
export { loopViewDefinition } from './loop-snapshot-builder.ts';
export { soleTask, type LoopTask } from './loop-tasks.ts';
export { chooseExecution, proposeExecution, resetLocalSelection, setSelectionSource, useProjectSelection, } from './selection-bridge.ts';
export type { ProjectSelection, SelectionPatch, SelectionSource } from './selection-bridge.ts';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map