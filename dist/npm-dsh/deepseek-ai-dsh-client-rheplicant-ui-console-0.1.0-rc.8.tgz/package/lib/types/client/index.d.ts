/**
 * Browser plugin for the rheplicant console. Registers a "Console"
 * conversation.view tab and DECLARES a child slot `console.panel` (a list grid)
 * that other plugins — posterior, spectrum, … — inject into. This is the
 * self-extensible slot mechanism: no DSH change, the slot is claimed here.
 * Also registers the `rheplicant-loop` conversation-view target (the loop
 * projection LoopRail and GatesPanel read) and its own `gates` console.panel
 * occupant — registered here, ahead of every dependent viz package's own
 * `apply()`, so Gates renders first in the panel list without needing an
 * explicit `order`.
 * @module @rheplicant/dsh-rheplicant-ui-console/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        'console.panel': {
            kind: 'list';
            scope: 'session';
        };
    }
}
export type { LoopContribution, LoopConversationViewNode, LoopGatesEntry, LoopRunEntry, LoopSnapshot, LoopValidateEntry, } from './loop-contract.ts';
export { loopViewDefinition } from './loop-snapshot-builder.ts';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map