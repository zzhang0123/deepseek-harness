/**
 * The console's read of the project, over the host's own route.
 *
 * `docs/project-model.md` §6.2, §8.1. A session log can only describe what that
 * session did; the project's full history is a directory read, and only the
 * host can do one. This is the browser half of `/rheplicant/project/executions`.
 *
 * Everything here degrades rather than fails. A composition without the route
 * plugin — a headless boot, an older harness, a test scaffold — answers 404,
 * and the header must go on showing this session's own executions rather than
 * break. `undefined` means "the project is not readable from here", which is a
 * different fact from "this project has no executions" and is rendered
 * differently.
 *
 * @module @rheplicant/dsh-rheplicant-ui-console/client/project-api-client
 */
import type { ProjectExecutionRow, ProjectExecutionsBody } from '@rheplicant/dsh-rheplicant';
/**
 * Every execution in this session's project, newest first.
 *
 * @param sessionId - the session whose workspace bounds the read. The host
 *   resolves the directory from this; no path is ever sent.
 * @param signal - abort when the component unmounts or the session changes.
 * @returns the project name and its rows, or `undefined` when the project
 *   cannot be read from here.
 */
export declare function fetchProjectExecutions(sessionId: string, signal?: AbortSignal): Promise<ProjectExecutionsBody | undefined>;
export type { ProjectExecutionRow, ProjectExecutionsBody };
//# sourceMappingURL=project-api-client.d.ts.map