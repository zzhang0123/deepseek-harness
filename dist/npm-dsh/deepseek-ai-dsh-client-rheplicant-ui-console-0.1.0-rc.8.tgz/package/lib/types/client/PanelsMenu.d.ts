import type { KnownPanel } from './known-panels.ts';
export interface PanelsMenuProps {
    readonly panels: readonly KnownPanel[];
    readonly hidden: ReadonlySet<string>;
    readonly onToggleHidden: (id: string) => void;
    readonly onReset: () => void;
}
export declare const PanelsMenu: import("react").MemoExoticComponent<({ panels, hidden, onToggleHidden, onReset }: PanelsMenuProps) => import("react").JSX.Element>;
//# sourceMappingURL=PanelsMenu.d.ts.map