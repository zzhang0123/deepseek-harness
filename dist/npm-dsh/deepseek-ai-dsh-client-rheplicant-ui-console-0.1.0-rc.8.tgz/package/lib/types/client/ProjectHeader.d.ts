import type { ConsoleExecutionState } from './use-console-execution.ts';
interface ProjectHeaderProps {
    /** The console's selection state — see `useConsoleExecution`. */
    execution: ConsoleExecutionState;
}
export declare const ProjectHeader: import("react").MemoExoticComponent<({ execution }: ProjectHeaderProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=ProjectHeader.d.ts.map