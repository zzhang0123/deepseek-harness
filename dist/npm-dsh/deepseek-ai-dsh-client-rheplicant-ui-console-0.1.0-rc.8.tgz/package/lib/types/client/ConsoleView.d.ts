import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
interface ConsoleViewProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    /** Root-scope standard prop; used only to resolve this session's project. */
    useWorkspaces: <T>(selector: (state: {
        items: readonly {
            workspaceId: string;
            sessionIds: readonly string[];
        }[];
    }) => T) => T;
}
export declare const ConsoleView: import("react").MemoExoticComponent<({ useSession, useWorkspaces }: ConsoleViewProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=ConsoleView.d.ts.map