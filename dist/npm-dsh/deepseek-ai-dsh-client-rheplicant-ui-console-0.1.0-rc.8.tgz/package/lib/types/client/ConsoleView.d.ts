/**
 * The console shell: a header row (the Panels menu) then the LoopRail (full
 * width, above the grid) then every `console.panel` occupant in a
 * responsive grid. `useSession` arrives on every `conversation.view` entry
 * through the session-scope standard kit (`PropsRuntime<'conversation.view'>`
 * — see ui-slots' `SessionStandardProps` merge); LoopRail is the console
 * shell's own reader of it, the same seat every console.panel occupant
 * already receives. `useStore`/`actions` arrive the same way `AppFrame`
 * receives its layout store (dsh's `ui-layout/src/client/AppFrame.tsx`):
 * this entry's OWN registration (in `index.ts`) declares `store:
 * createConsoleLayoutStore`, so the framework bakes `useStore`/`actions`
 * straight into this component's props — see `layout-store.ts`'s doc
 * comment for why the store lives HERE (on ConsoleView's own registration)
 * rather than on any one `console.panel` occupant.
 *
 * Per-entry `console.panel` render control: NOT available. `renderSlot`'s
 * `RenderOpts.only` (dsh's `ui-slots/src/index.ts`) filters a list slot down
 * to ONE entry by id — it cannot express "every entry except these hidden
 * ones", and there is no read API to enumerate registered entries from a
 * slot component in the first place (`PropsRenderSlots` offers only
 * `renderSlot`/`renderSlotChain`; entry enumeration lives on
 * `SlotRendererHost`, internal to `ui-renderer`, never exposed to a
 * component). So this file renders `console.panel` UNFILTERED (every
 * occupant, same as before) and hands the resolved layout view down through
 * the one channel every occupant actually receives — the shared owner props
 * object (`ui-renderer/src/client/scoped-slots.tsx`'s list branch calls
 * `guarded(entry, key)` with no per-row owner override, so `renderSlot`'s
 * second argument really is identical for every row). `ConsolePanelLayoutView`
 * (ui-kit) documents the same thing from the occupant's side. Concretely, all
 * six occupants — `gates` (this package), `posterior`/`chains`
 * (ui-posterior), `signal-path` (ui-analysis), `identifiability`
 * (ui-identifiability), `spectrum` (ui-spectrum) — read `layout` off this
 * shared object and self-apply it (hidden → render nothing, collapsed → pass
 * `collapsed`/`onToggleCollapse` down to the kit `Panel`). A future occupant
 * that skips this is simply unmanaged by the console's layout — no error, it
 * stays always-visible/always-expanded, same as before any occupant wired it
 * (an occupant ignoring an unknown prop is just an occupant ignoring an
 * unknown prop, not a contract break).
 * @module @rheplicant/dsh-rheplicant-ui-console/client/ConsoleView
 */
import { type ReactNode } from 'react';
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createConsoleLayoutStore } from './layout-store.ts';
/**
 * `useStore`/`actions` derive from the store handle's own return type
 * (`PropsStore<H>`, dsh's `ui-slots/src/store.ts`) rather than a hand-typed
 * twin of the actions declared in `layout-store.ts` — the same
 * `PropsStore<ReturnType<typeof createLayoutStore>>` pattern
 * `ui-layout/src/client/AppFrame.tsx` uses for its own layout store. Baked
 * per-call args ARE what a caller of `actions.toggleCollapsed` writes
 * (`(id: string) => void` — the draft parameter is gone, baked away by the
 * framework); deriving this mechanically rather than hand-declaring a second
 * "actions" shape is what keeps that fact from drifting out of sync with
 * `layout-store.ts`'s own declared write set.
 */
type ConsoleViewProps = {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    renderSlot: (key: 'console.panel', owner: object) => ReactNode;
} & PropsStore<ReturnType<typeof createConsoleLayoutStore>>;
export declare const ConsoleView: import("react").MemoExoticComponent<({ useSession, renderSlot, useStore, actions }: ConsoleViewProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=ConsoleView.d.ts.map