/**
 * The console's one source of "which execution are we showing, and what is in
 * it" — shared by the header that names it and the panels that render it.
 *
 * `docs/project-model.md` §6.1, §6.2. Both halves have to agree: a header
 * naming one execution above panels drawing another is the exact confusion
 * this console exists to remove, so the selection and its data are owned in one
 * place and handed down.
 *
 * @module @rheplicant/dsh-rheplicant-ui-console/client/use-console-execution
 */
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { ConsoleExecutionView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
import { type HeaderExecution } from './project-selectors.ts';
/** Everything the console shell needs to render a selection. */
export interface ConsoleExecutionState {
    /** Every offerable execution, newest first. */
    readonly ordered: readonly HeaderExecution[];
    /** The one being shown, or undefined when there is none. */
    readonly selected: HeaderExecution | undefined;
    /** The newest id, which is what "current" means. */
    readonly newest: string | undefined;
    /** The project's name, when it is known. */
    readonly projectName: string | undefined;
    /** False when the project routes could not be reached at all. */
    readonly projectReadable: boolean;
    /** Choose an execution; passing the newest id returns to following it. */
    readonly select: (executionId: string) => void;
    /** What every console panel receives through the slot's owner props. */
    readonly executionView: ConsoleExecutionView;
}
type SessionReader = <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
/**
 * Own the console's selection and the data behind it.
 * @param useSession - the standard `conversation.view` session reader.
 * @returns the selection, the list, and the panels' execution view.
 */
export declare function useConsoleExecution(useSession: SessionReader): ConsoleExecutionState;
export {};
//# sourceMappingURL=use-console-execution.d.ts.map