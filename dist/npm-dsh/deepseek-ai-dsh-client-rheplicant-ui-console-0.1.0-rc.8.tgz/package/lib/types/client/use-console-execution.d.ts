/**
 * Which execution this conversation is looking at.
 *
 * `docs/project-model.md` §6.1. The selection belongs to the PROJECT (§11.2),
 * so this reads and writes the project's; the session's remaining job is to
 * say which executions it produced and which project it is in.
 *
 * **It used to project the selected execution's DATA as well**, for the panels
 * the console tab carried. §20.4 moved those panels to the workbench, which
 * does its own read (`use-workbench-execution.ts`) — so keeping the projection
 * here would be a second host round-trip per selection, in every open console
 * tab, for a body nothing renders.
 *
 * @module @rheplicant/dsh-rheplicant-ui-console/client/use-console-execution
 */
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { type HeaderExecution } from './project-selectors.ts';
/** Everything the console shell needs to render a selection. */
export interface ConsoleExecutionState {
    /** Every offerable execution, newest first. */
    readonly ordered: readonly HeaderExecution[];
    /** The one being shown, or undefined when there is none. */
    readonly selected: HeaderExecution | undefined;
    /** The newest id, which is what "current" means. */
    readonly newest: string | undefined;
    /** The project's name, when it is known. */
    readonly projectName: string | undefined;
    /** False when the project routes could not be reached at all. */
    readonly projectReadable: boolean;
    /**
     * True when a human pinned this execution, so the newest-by-default rule is
     * NOT what is on screen. The header says which rule is in force, and it can
     * only do that if it is told.
     */
    readonly pinned: boolean;
    /** Choose an execution; passing the newest id returns to following it. */
    readonly select: (executionId: string) => void;
}
type SessionReader = <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
/** Just enough of the workspace list to find which project this session is in. */
interface WorkspaceListLike {
    items: readonly {
        workspaceId: string;
        sessionIds: readonly string[];
    }[];
}
type WorkspaceReader = <T>(selector: (state: WorkspaceListLike) => T) => T;
/**
 * Read the console's selection and the data behind it.
 *
 * The selection is NOT owned here any more (`docs/project-model.md` §11.2). It
 * belongs to the project, so this hook reads and writes the project's, and the
 * session's only remaining job is to say which executions it produced and
 * which project it is in.
 *
 * @param useSession - the standard `conversation.view` session reader.
 * @param useWorkspaces - the standard workspace-list reader, used only to
 *   resolve this session's project.
 * @returns the selection and the list.
 */
export declare function useConsoleExecution(useSession: SessionReader, useWorkspaces?: WorkspaceReader): ConsoleExecutionState;
export {};
//# sourceMappingURL=use-console-execution.d.ts.map