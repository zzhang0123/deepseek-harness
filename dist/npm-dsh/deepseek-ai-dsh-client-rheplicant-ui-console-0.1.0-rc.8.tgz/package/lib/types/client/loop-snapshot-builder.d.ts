/**
 * Per-session incremental builder for the `rheplicant-loop` conversation-view
 * target. Structure copied from ui-trajectory's `trajectory-snapshot-builder.ts`
 * (the only reference for this pattern): a `Map<key, Node>` ledger, a sorted
 * `contributions` cache rebuilt only on structural change (a new key, or an
 * existing key's `anchorSeq` moving), and a `snapshot()` fold that walks the
 * sorted contributions once. Unlike Trajectory's ledger (which keeps every
 * contribution as a list entry), the loop fold keeps only the LATEST fact of
 * each kind — later events of a type replace earlier ones, because the loop
 * iterates on one document rather than accumulating a transcript.
 * @module @rheplicant/dsh-rheplicant-ui-console/client/loop-snapshot-builder
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ConversationViewBuilder, ConversationViewDefinition } from '@deepseek-ai/dsh-client-runtime/client';
import type { LoopConversationViewNode, LoopSnapshot } from './loop-contract.ts';
/** Stable empty target used until a Session has assembled any loop records. */
export declare const EMPTY_LOOP_SNAPSHOT: LoopSnapshot;
/** Per-Session incremental builder folding validate/gates/run contributions into one loop state. */
export declare class LoopSnapshotBuilder implements ConversationViewBuilder<LoopConversationViewNode, LoopSnapshot> {
    private readonly nodes;
    private readonly positions;
    private contributions;
    readonly empty: LoopSnapshot;
    replace(input: {
        readonly nodes: readonly LoopConversationViewNode[];
    }): LoopSnapshot;
    apply(input: {
        readonly upserts: readonly LoopConversationViewNode[];
    }): LoopSnapshot;
    /**
     * Fold the sorted contributions into the final loop state: later facts of
     * one kind overwrite earlier ones as the walk proceeds in ascending
     * `anchorSeq` order, so the result always holds the latest of each kind.
     */
    private snapshot;
    private rebuildContributions;
}
/** The loop target factory: one fresh builder per Session. */
export declare const loopViewDefinition: ConversationViewDefinition<LoopConversationViewNode, LoopSnapshot>;
/**
 * Register the `rheplicant-loop` conversation-view target builder.
 * @param ctx - Plugin context receiving the view Definition.
 */
export declare function registerLoopConversationView(ctx: Context): void;
//# sourceMappingURL=loop-snapshot-builder.d.ts.map