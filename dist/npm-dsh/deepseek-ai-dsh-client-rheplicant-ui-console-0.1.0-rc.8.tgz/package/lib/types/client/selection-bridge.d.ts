/**
 * How the console reaches the PROJECT's selection (`docs/project-model.md`
 * §11.2).
 *
 * The selection lives in `ui-project`, in a different client bundle, so the
 * console reaches it through `ctx.get('rheplicantSelection')` — captured here
 * by `apply()`, because React components have no route to the plugin context.
 *
 * **The fallback is deliberately dumber than the real thing.** With no project
 * surface mounted there is exactly one writer — this console — so there is no
 * conflict for pinning to arbitrate, and `propose` collapses into `select`.
 * Reimplementing the pin semantics here would be duplicating a rule that
 * cannot fire.
 *
 * @module @rheplicant/dsh-rheplicant-ui-console/client/selection-bridge
 */
/** The axes a caller may set; an absent axis is left alone. */
export interface SelectionPatch {
    readonly taskPath?: string | undefined;
    readonly executionId?: string | undefined;
}
/** What one project is showing. */
export interface ProjectSelection {
    readonly taskPath: string | undefined;
    readonly executionId: string | undefined;
    readonly pinned: {
        readonly task: boolean;
        readonly execution: boolean;
    };
}
/** The face `ui-project` publishes, as this package needs it. */
export interface SelectionSource {
    select(workspaceId: string, patch: SelectionPatch): void;
    propose(workspaceId: string, patch: SelectionPatch): void;
    read(workspaceId: string): ProjectSelection;
    subscribe(listener: () => void): () => void;
}
/**
 * Install the lookup. Called once from `apply()`.
 * @param next - the thunk, or undefined to uninstall (tests).
 */
export declare function setSelectionSource(next: (() => SelectionSource | undefined) | undefined): void;
/**
 * Subscribe a component to one project's selection.
 * @param workspaceId - the project to watch, or undefined when it is unknown.
 * @returns its selection, or the untouched state.
 */
export declare function useProjectSelection(workspaceId: string | undefined): ProjectSelection;
/**
 * Choose an execution explicitly — what the console's picker does.
 * @param workspaceId - the project.
 * @param executionId - the execution the human picked.
 */
export declare function chooseExecution(workspaceId: string | undefined, executionId: string): void;
/**
 * Offer an execution as the default — what a finished run does.
 * @param workspaceId - the project.
 * @param executionId - the execution that just became available.
 */
export declare function proposeExecution(workspaceId: string | undefined, executionId: string): void;
/** Drop the local stand-in's state. Exists for tests, which share a module. */
export declare function resetLocalSelection(): void;
//# sourceMappingURL=selection-bridge.d.ts.map