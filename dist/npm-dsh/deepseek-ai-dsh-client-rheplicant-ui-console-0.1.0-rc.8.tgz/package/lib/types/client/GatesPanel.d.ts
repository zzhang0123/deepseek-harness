import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { type ConsolePanelLayoutView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
interface GatesPanelProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    /** Console layout state (owner prop — see ConsoleView's doc comment). Absent when not rendered through the console shell (e.g. a unit test): renders un-collapsed, always visible. */
    layout?: ConsolePanelLayoutView;
}
export declare const GatesPanel: import("react").MemoExoticComponent<({ useSession, layout }: GatesPanelProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=GatesPanel.d.ts.map