import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
interface LoopRailProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
}
export declare const LoopRail: import("react").MemoExoticComponent<({ useSession }: LoopRailProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=LoopRail.d.ts.map