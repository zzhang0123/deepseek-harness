/**
 * Browser plugin for the identifiability panel. Injects into the `console.panel`
 * slot declared by ui-console — the separate-viz-plugin contract: this package
 * reads nothing but the log, and does not re-run compute.
 * @module @rheplicant/dsh-rheplicant-ui-identifiability/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map