/** Package-owned invariant companion for `@rheplicant/dsh-rheplicant-ui-identifiability`. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "rheplicant-ui-identifiability-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map