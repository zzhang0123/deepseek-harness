import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { type LoopExecutionView, type PanelLayoutView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
interface SignalPathPanelProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    /**
     * The execution being shown (owner prop), so this panel draws the SELECTED
     * execution's model rather than the open conversation's. Absent outside the
     * console shell, where the session log is the only source there is.
     */
    execution?: LoopExecutionView;
    /** Panel layout state (owner prop — see ui-project's ProjectHome doc comment). Absent when not rendered through a panel grid (e.g. a unit test): renders un-collapsed, always visible. */
    layout?: PanelLayoutView;
}
export declare const SignalPathPanel: import("react").MemoExoticComponent<({ useSession, layout, execution }: SignalPathPanelProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=SignalPathPanel.d.ts.map