import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { type ConsolePanelLayoutView } from '@rheplicant/dsh-rheplicant-ui-kit/client';
interface SignalPathPanelProps {
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    /** Console layout state (owner prop — see ui-console's ConsoleView doc comment). Absent when not rendered through the console shell (e.g. a unit test): renders un-collapsed, always visible. */
    layout?: ConsolePanelLayoutView;
}
export declare const SignalPathPanel: import("react").MemoExoticComponent<({ useSession, layout }: SignalPathPanelProps) => import("react").JSX.Element | null>;
export {};
//# sourceMappingURL=SignalPathPanel.d.ts.map