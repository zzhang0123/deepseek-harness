import type { ChatNodeViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
/**
 * Just enough of the workspace list to say which project a session is in. The
 * same lookup `useLoopExecution` does, and for the same reason: a session
 * belongs to at most one workspace, so this is a lookup, not a choice.
 */
interface WorkspaceListLike {
    items: readonly {
        workspaceId: string;
        sessionIds: readonly string[];
    }[];
}
/** Render one analysis run's step list with per-run status and diagnostics. */
export declare const AnalysisRunPanel: import("react").MemoExoticComponent<({ node, sessionId, useWorkspaces }: ChatNodeViewProps<"rheplicant-analysis"> & {
    useWorkspaces?: <T>(selector: (state: WorkspaceListLike) => T) => T;
}) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=AnalysisRunPanel.d.ts.map