import type { ChatNodeViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
/** Render one analysis run's step list with per-run status and diagnostics. */
export declare const AnalysisRunPanel: import("react").MemoExoticComponent<({ node }: ChatNodeViewProps<"rheplicant-analysis">) => import("react").JSX.Element>;
//# sourceMappingURL=AnalysisRunPanel.d.ts.map