/**
 * Browser plugin for the durable rheplicant analysis-run Conversation Node.
 * Registers the Definition, its keyed `conversation.chat.node` renderer, and
 * a second occupant of ui-project's `task.panel` grid — `signal-path` —
 * mirroring ui-posterior's two-registrations-one-plugin pattern.
 * @module @rheplicant/dsh-rheplicant-ui-analysis/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { canOpenInProject, openInProject, setProjectSurface, } from './project-bridge.ts';
export type { ProjectSurface, ResultAddress, SelectionPatch, SelectionSource, WorkbenchSource, } from './project-bridge.ts';
/** Required services for the Definition, the keyed renderer, and the task.panel registration. */
export declare const inject: string[];
/** Register the rheplicant-analysis Definition, its keyed renderer, and the signal-path workbench panel. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map