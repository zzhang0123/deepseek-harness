/**
 * The `rheplicant-analysis` Conversation Node: folds one durable `rheplicant/run`
 * event into a keyed Chat node carrying the run list, its statuses, and each
 * run's diagnostics (r_hat, identifiability rank, joint χ²) — projected here so
 * the renderer can surface them separately from the model's prose. The
 * definition owns identity, matching, and the durable state fold.
 * @module @rheplicant/dsh-rheplicant-ui-analysis/client
 */
import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-runtime/client';
import type { GateFinding, RunDiagnostics, RunOutcome, SignalPathGraph, Transport } from '@rheplicant/dsh-rheplicant';
/** Final keyed Chat payload for one analysis run. */
export interface AnalysisRunChatData {
    readonly runs: readonly {
        readonly name: string;
        readonly kind: string;
        readonly status: 'ok' | 'failed';
        readonly diagnostics?: RunDiagnostics;
        /** Passed through verbatim from the wire `RunEntry.chains` (see its key grammar; nulls = non-finite). */
        readonly chains?: Record<string, (number | null)[]>;
        readonly spectrum?: (number | null)[][];
        /**
         * Provenance, folded in from the owning `rheplicant/run` event rather
         * than the wire `RunEntry` (which carries none of this) — every run in
         * one event's `outcome.runs` shares the same `time`/`transport`/`seq`,
         * which is exactly the point: it is how two runs from DIFFERENT events
         * (e.g. a rerun with an identical seed producing a byte-identical
         * outcome) still read as distinct cards instead of one repeated. Kept
         * optional/additive so nothing that predates this field breaks.
         */
        readonly time?: number;
        readonly transport?: Transport;
        readonly seq?: number;
        /**
         * Execution identity, folded in from the same event
         * (`docs/project-model.md` §4.1). `seq` only orders events inside one
         * session log; `executionId` names the execution durably, and
         * `taskPath` names the file it ran. Optional/additive for exactly the
         * same reason as `time`/`transport`/`seq`: events recorded before
         * execution identity existed carry neither.
         */
        readonly executionId?: string;
        readonly taskPath?: string;
    }[];
    readonly tookMs?: number;
    readonly graph?: SignalPathGraph;
    readonly gates?: readonly GateFinding[];
}
declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
    interface ChatNodeDataMap {
        'rheplicant-analysis': AnalysisRunChatData;
    }
}
interface AnalysisState {
    readonly outcome?: RunOutcome;
    readonly transport?: Transport;
    readonly executionId?: string;
    readonly taskPath?: string;
}
/** Fold one durable `rheplicant/run` event into a keyed Chat node. */
export declare const analysisRunDefinition: ConversationNodeDefinition<AnalysisState>;
export {};
//# sourceMappingURL=analysis-definition.d.ts.map