import type { SignalPathGraph } from '@rheplicant/dsh-rheplicant';
export declare const SignalPath: import("react").MemoExoticComponent<({ graph }: {
    graph: SignalPathGraph;
}) => import("react").JSX.Element>;
//# sourceMappingURL=SignalPath.d.ts.map